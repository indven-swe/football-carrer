package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PlayerProfileEntity::class,
        CalendarActivityEntity::class,
        MatchRecordEntity::class,
        TrainingRecordEntity::class,
        AchievementEntity::class,
        ChallengeEntity::class,
        TrophyAndRewardEntity::class,
        SeasonSummaryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class FootballCareerDatabase : RoomDatabase() {
    abstract fun playerProfileDao(): PlayerProfileDao
    abstract fun calendarActivityDao(): CalendarActivityDao
    abstract fun matchRecordDao(): MatchRecordDao
    abstract fun trainingRecordDao(): TrainingRecordDao
    abstract fun achievementDao(): AchievementDao
    abstract fun challengeDao(): ChallengeDao
    abstract fun trophyAndRewardDao(): TrophyAndRewardDao
    abstract fun seasonSummaryDao(): SeasonSummaryDao

    companion object {
        @Volatile
        private var INSTANCE: FootballCareerDatabase? = null

        fun getInstance(context: Context): FootballCareerDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FootballCareerDatabase::class.java,
                    "football_career_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
