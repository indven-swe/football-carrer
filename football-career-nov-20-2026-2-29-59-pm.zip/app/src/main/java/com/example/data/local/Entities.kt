package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_profile")
data class PlayerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val photoUri: String? = null,
    val position: String,
    val preferredFoot: String,
    val club: String,
    val jerseyNumber: Int,
    val age: Int,
    val nationality: String,
    val ovrRating: Int,
    val level: Int,
    val totalXp: Int,
    val pace: Int,
    val shooting: Int,
    val passing: Int,
    val dribbling: Int,
    val defending: Int,
    val physical: Int,
    val cardDesign: String,
    val cardBackground: String,
    val cardBorder: String,
    val cardColorTheme: String,
    val cardRarity: String,
    val currentSeasonNumber: Int = 1,
    val activeStreakDays: Int = 1,
    val longestStreakDays: Int = 1,
    val lastActiveEpochDay: Long = 0L,
    val appThemeId: String = "neon_green"
)

@Entity(tableName = "calendar_activities")
data class CalendarActivityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String,
    val startTimeMillis: Long,
    val durationMinutes: Int,
    val location: String,
    val notes: String,
    val isAwayMatch: Boolean = false,
    val notify1h: Boolean = true,
    val notify30m: Boolean = true,
    val notify15m: Boolean = true,
    val isCompleted: Boolean = false
)

@Entity(tableName = "match_records")
data class MatchRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val opponent: String,
    val dateEpochMillis: Long,
    val goalsFor: Int,
    val goalsAgainst: Int,
    val position: String,
    val minutesPlayed: Int,
    val goals: Int,
    val assists: Int,
    val isManOfTheMatch: Boolean,
    val performanceRating: Float,
    val isAway: Boolean,
    val isDecisiveGoal: Boolean,
    val notes: String,
    val seasonNumber: Int,
    val xpEarned: Int
)

@Entity(tableName = "training_records")
data class TrainingRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val skillFocused: String,
    val durationMinutes: Int,
    val intensity: String,
    val performanceRating: Float,
    val notes: String,
    val dateEpochMillis: Long,
    val seasonNumber: Int,
    val xpEarned: Int
)

@Entity(tableName = "achievements")
data class AchievementEntity(
    @PrimaryKey val id: Int,
    val key: String,
    val title: String,
    val description: String,
    val rarity: String,
    val requirementText: String,
    val xpReward: Int,
    val isUnlocked: Boolean = false,
    val unlockedAtMillis: Long? = null,
    val progressCurrent: Int = 0,
    val progressTarget: Int = 1
)

@Entity(tableName = "challenges")
data class ChallengeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val category: String,
    val targetCount: Int,
    val currentCount: Int = 0,
    val xpReward: Int,
    val isCompleted: Boolean = false,
    val assignedEpochDay: Long,
    val challengeKey: String
)

@Entity(tableName = "trophies_and_rewards")
data class TrophyAndRewardEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subtitle: String,
    val type: String,
    val rarity: String,
    val seasonNumber: Int,
    val unlockedAtMillis: Long
)

@Entity(tableName = "season_summaries")
data class SeasonSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val seasonNumber: Int,
    val clubName: String,
    val matchesPlayed: Int,
    val goals: Int,
    val assists: Int,
    val trainingsCompleted: Int,
    val totalXpEarned: Int,
    val mostPlayedPosition: String,
    val bestPerformanceText: String,
    val achievementsUnlockedCount: Int,
    val startOvr: Int,
    val endOvr: Int,
    val endedAtMillis: Long
)
