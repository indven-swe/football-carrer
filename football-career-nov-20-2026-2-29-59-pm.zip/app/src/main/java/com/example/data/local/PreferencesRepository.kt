package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.NotificationSoundOption
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.careerPrefsDataStore: DataStore<Preferences> by preferencesDataStore(name = "career_settings")

data class NotificationPreferences(
    val remindersEnabled: Boolean = true,
    val notify1hEnabled: Boolean = true,
    val notify30mEnabled: Boolean = true,
    val notify15mEnabled: Boolean = true,
    val achievementNotificationsEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val matchSoundId: String = NotificationSoundOption.WHISTLE.id,
    val trainingSoundId: String = NotificationSoundOption.TRAINING_PULSE.id,
    val urgentSoundId: String = NotificationSoundOption.URGENT_HORN.id
)

class PreferencesRepository(private val context: Context) {

    private object Keys {
        val REMINDERS_ENABLED = booleanPreferencesKey("reminders_enabled")
        val NOTIFY_1H = booleanPreferencesKey("notify_1h")
        val NOTIFY_30M = booleanPreferencesKey("notify_30m")
        val NOTIFY_15M = booleanPreferencesKey("notify_15m")
        val ACHIEVEMENT_NOTIFS = booleanPreferencesKey("achievement_notifs")
        val VIBRATION_ENABLED = booleanPreferencesKey("vibration_enabled")
        val MATCH_SOUND = stringPreferencesKey("match_sound_id")
        val TRAINING_SOUND = stringPreferencesKey("training_sound_id")
        val URGENT_SOUND = stringPreferencesKey("urgent_sound_id")
        val UNOPENED_PACKS = intPreferencesKey("unopened_packs")
        val SEASON_START_OVR = intPreferencesKey("season_start_ovr")
    }

    val notificationPreferences: Flow<NotificationPreferences> = context.careerPrefsDataStore.data.map { prefs ->
        NotificationPreferences(
            remindersEnabled = prefs[Keys.REMINDERS_ENABLED] ?: true,
            notify1hEnabled = prefs[Keys.NOTIFY_1H] ?: true,
            notify30mEnabled = prefs[Keys.NOTIFY_30M] ?: true,
            notify15mEnabled = prefs[Keys.NOTIFY_15M] ?: true,
            achievementNotificationsEnabled = prefs[Keys.ACHIEVEMENT_NOTIFS] ?: true,
            vibrationEnabled = prefs[Keys.VIBRATION_ENABLED] ?: true,
            matchSoundId = prefs[Keys.MATCH_SOUND] ?: NotificationSoundOption.WHISTLE.id,
            trainingSoundId = prefs[Keys.TRAINING_SOUND] ?: NotificationSoundOption.TRAINING_PULSE.id,
            urgentSoundId = prefs[Keys.URGENT_SOUND] ?: NotificationSoundOption.URGENT_HORN.id
        )
    }

    val unopenedPacksCount: Flow<Int> = context.careerPrefsDataStore.data.map { prefs ->
        prefs[Keys.UNOPENED_PACKS] ?: 1
    }

    val seasonStartOvr: Flow<Int> = context.careerPrefsDataStore.data.map { prefs ->
        prefs[Keys.SEASON_START_OVR] ?: 64
    }

    suspend fun getNotificationPreferencesOnce(): NotificationPreferences =
        notificationPreferences.first()

    suspend fun updateNotificationPreferences(updated: NotificationPreferences) {
        context.careerPrefsDataStore.edit { prefs ->
            prefs[Keys.REMINDERS_ENABLED] = updated.remindersEnabled
            prefs[Keys.NOTIFY_1H] = updated.notify1hEnabled
            prefs[Keys.NOTIFY_30M] = updated.notify30mEnabled
            prefs[Keys.NOTIFY_15M] = updated.notify15mEnabled
            prefs[Keys.ACHIEVEMENT_NOTIFS] = updated.achievementNotificationsEnabled
            prefs[Keys.VIBRATION_ENABLED] = updated.vibrationEnabled
            prefs[Keys.MATCH_SOUND] = updated.matchSoundId
            prefs[Keys.TRAINING_SOUND] = updated.trainingSoundId
            prefs[Keys.URGENT_SOUND] = updated.urgentSoundId
        }
    }

    suspend fun addPacks(count: Int) {
        context.careerPrefsDataStore.edit { prefs ->
            val current = prefs[Keys.UNOPENED_PACKS] ?: 1
            prefs[Keys.UNOPENED_PACKS] = (current + count).coerceAtLeast(0)
        }
    }

    suspend fun consumePack(): Boolean {
        var consumed = false
        context.careerPrefsDataStore.edit { prefs ->
            val current = prefs[Keys.UNOPENED_PACKS] ?: 1
            if (current > 0) {
                prefs[Keys.UNOPENED_PACKS] = current - 1
                consumed = true
            }
        }
        return consumed
    }

    suspend fun setSeasonStartOvr(ovr: Int) {
        context.careerPrefsDataStore.edit { prefs ->
            prefs[Keys.SEASON_START_OVR] = ovr
        }
    }

    suspend fun getSeasonStartOvrOnce(): Int = seasonStartOvr.first()
}
