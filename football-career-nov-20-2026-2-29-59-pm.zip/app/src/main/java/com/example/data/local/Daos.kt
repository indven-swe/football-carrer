package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PlayerProfileDao {
    @Query("SELECT * FROM player_profile WHERE id = 1")
    fun observeProfile(): Flow<PlayerProfileEntity?>

    @Query("SELECT * FROM player_profile WHERE id = 1")
    suspend fun getProfileOnce(): PlayerProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: PlayerProfileEntity)
}

@Dao
interface CalendarActivityDao {
    @Query("SELECT * FROM calendar_activities ORDER BY startTimeMillis ASC")
    fun observeAllActivities(): Flow<List<CalendarActivityEntity>>

    @Query("SELECT * FROM calendar_activities WHERE startTimeMillis >= :nowMillis ORDER BY startTimeMillis ASC")
    suspend fun getFutureActivitiesOnce(nowMillis: Long): List<CalendarActivityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivity(activity: CalendarActivityEntity): Long

    @Update
    suspend fun updateActivity(activity: CalendarActivityEntity)

    @Query("DELETE FROM calendar_activities WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface MatchRecordDao {
    @Query("SELECT * FROM match_records ORDER BY dateEpochMillis DESC")
    fun observeAllMatches(): Flow<List<MatchRecordEntity>>

    @Query("SELECT * FROM match_records ORDER BY dateEpochMillis DESC")
    suspend fun getAllMatchesOnce(): List<MatchRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: MatchRecordEntity): Long

    @Query("DELETE FROM match_records WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface TrainingRecordDao {
    @Query("SELECT * FROM training_records ORDER BY dateEpochMillis DESC")
    fun observeAllTrainings(): Flow<List<TrainingRecordEntity>>

    @Query("SELECT * FROM training_records ORDER BY dateEpochMillis DESC")
    suspend fun getAllTrainingsOnce(): List<TrainingRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTraining(training: TrainingRecordEntity): Long

    @Query("DELETE FROM training_records WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements ORDER BY id ASC")
    fun observeAllAchievements(): Flow<List<AchievementEntity>>

    @Query("SELECT * FROM achievements ORDER BY id ASC")
    suspend fun getAllAchievementsOnce(): List<AchievementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(achievements: List<AchievementEntity>)

    @Update
    suspend fun updateAll(achievements: List<AchievementEntity>)
}

@Dao
interface ChallengeDao {
    @Query("SELECT * FROM challenges ORDER BY isCompleted ASC, id DESC")
    fun observeAllChallenges(): Flow<List<ChallengeEntity>>

    @Query("SELECT * FROM challenges")
    suspend fun getAllChallengesOnce(): List<ChallengeEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChallenge(challenge: ChallengeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(challenges: List<ChallengeEntity>)

    @Update
    suspend fun updateChallenge(challenge: ChallengeEntity)

    @Query("DELETE FROM challenges WHERE assignedEpochDay < :minEpochDay AND category = 'DAGLIG'")
    suspend fun clearOldDailyChallenges(minEpochDay: Long)
}

@Dao
interface TrophyAndRewardDao {
    @Query("SELECT * FROM trophies_and_rewards ORDER BY unlockedAtMillis DESC")
    fun observeAllTrophies(): Flow<List<TrophyAndRewardEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrophy(trophy: TrophyAndRewardEntity): Long
}

@Dao
interface SeasonSummaryDao {
    @Query("SELECT * FROM season_summaries ORDER BY seasonNumber DESC")
    fun observeSeasonSummaries(): Flow<List<SeasonSummaryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSeasonSummary(summary: SeasonSummaryEntity): Long
}
