package com.example.data.repository

import android.content.Context
import com.example.data.local.AchievementEntity
import com.example.data.local.CalendarActivityEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.FootballCareerDatabase
import com.example.data.local.MatchRecordEntity
import com.example.data.local.NotificationPreferences
import com.example.data.local.PlayerProfileEntity
import com.example.data.local.PreferencesRepository
import com.example.data.local.SeasonSummaryEntity
import com.example.data.local.TrainingRecordEntity
import com.example.data.local.TrophyAndRewardEntity
import com.example.domain.AchievementDefinitions
import com.example.domain.AchievementRarity
import com.example.domain.ActivityType
import com.example.domain.CardBackgroundStyle
import com.example.domain.CardBorderStyle
import com.example.domain.CardColorPalette
import com.example.domain.CardDesignStyle
import com.example.domain.CardRarityTier
import com.example.domain.CareerEngine
import com.example.domain.ChallengeCategory
import com.example.domain.PackRewardResult
import com.example.domain.PlayerPosition
import com.example.domain.PreferredFoot
import com.example.domain.TrainingIntensity
import com.example.domain.TrainingType
import com.example.notifications.NotificationHelper
import com.example.notifications.ReminderScheduler
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.TimeUnit

class CareerRepository(
    private val context: Context,
    private val db: FootballCareerDatabase,
    private val prefsRepo: PreferencesRepository
) {
    private val playerDao = db.playerProfileDao()
    private val calendarDao = db.calendarActivityDao()
    private val matchDao = db.matchRecordDao()
    private val trainingDao = db.trainingRecordDao()
    private val achievementDao = db.achievementDao()
    private val challengeDao = db.challengeDao()
    private val trophyDao = db.trophyAndRewardDao()
    private val seasonDao = db.seasonSummaryDao()

    val playerProfile: Flow<PlayerProfileEntity?> = playerDao.observeProfile()
    val calendarActivities: Flow<List<CalendarActivityEntity>> = calendarDao.observeAllActivities()
    val matches: Flow<List<MatchRecordEntity>> = matchDao.observeAllMatches()
    val trainings: Flow<List<TrainingRecordEntity>> = trainingDao.observeAllTrainings()
    val achievements: Flow<List<AchievementEntity>> = achievementDao.observeAllAchievements()
    val challenges: Flow<List<ChallengeEntity>> = challengeDao.observeAllChallenges()
    val trophies: Flow<List<TrophyAndRewardEntity>> = trophyDao.observeAllTrophies()
    val seasonSummaries: Flow<List<SeasonSummaryEntity>> = seasonDao.observeSeasonSummaries()
    val notificationPreferences: Flow<NotificationPreferences> = prefsRepo.notificationPreferences
    val unopenedPacksCount: Flow<Int> = prefsRepo.unopenedPacksCount

    private val _unlockedAchievementEvents = MutableSharedFlow<AchievementEntity>(extraBufferCapacity = 8)
    val unlockedAchievementEvents: SharedFlow<AchievementEntity> = _unlockedAchievementEvents.asSharedFlow()

    private fun todayEpochDay(): Long = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis())

    suspend fun ensureInitialized() {
        val today = todayEpochDay()
        if (playerDao.getProfileOnce() == null) {
            val defaultProfile = PlayerProfileEntity(
                id = 1,
                name = "Ny Spelare",
                photoUri = null,
                position = PlayerPosition.CM.code,
                preferredFoot = PreferredFoot.HÖGER.name,
                club = "Min Fotbollsklubb",
                jerseyNumber = 10,
                age = 20,
                nationality = "Sverige",
                ovrRating = 65,
                level = 1,
                totalXp = 0,
                pace = 66,
                shooting = 64,
                passing = 67,
                dribbling = 66,
                defending = 60,
                physical = 65,
                cardDesign = CardDesignStyle.FUTURISTISK.name,
                cardBackground = CardBackgroundStyle.KOLFIBER.name,
                cardBorder = CardBorderStyle.NEON_GLÖD.name,
                cardColorTheme = CardColorPalette.NEONGRÖN.name,
                cardRarity = CardRarityTier.BRONS.name,
                currentSeasonNumber = 1,
                activeStreakDays = 1,
                longestStreakDays = 1,
                lastActiveEpochDay = today,
                appThemeId = "neon_green"
            )
            playerDao.upsertProfile(defaultProfile)
            prefsRepo.setSeasonStartOvr(defaultProfile.ovrRating)
        }

        if (achievementDao.getAllAchievementsOnce().isEmpty()) {
            achievementDao.insertAll(AchievementDefinitions.createInitialAchievements())
        }

        refreshDailyAndWeeklyChallenges(today)
        val prefs = prefsRepo.getNotificationPreferencesOnce()
        NotificationHelper.ensureChannels(context, prefs)
    }

    private suspend fun refreshDailyAndWeeklyChallenges(today: Long) {
        challengeDao.clearOldDailyChallenges(today)
        val existing = challengeDao.getAllChallengesOnce()
        val hasDailyToday = existing.any { it.category == ChallengeCategory.DAGLIG.name && it.assignedEpochDay == today }
        if (!hasDailyToday) {
            val dailyTemplates = AchievementDefinitions.dailyPool.shuffled().take(2)
            challengeDao.insertAll(dailyTemplates.map { AchievementDefinitions.toEntity(it, today) })
        }
        val hasWeekly = existing.any { it.category == ChallengeCategory.VECKOVIS.name }
        if (!hasWeekly) {
            val weeklyEntities = AchievementDefinitions.weeklyPool.map { AchievementDefinitions.toEntity(it, today) }
            challengeDao.insertAll(weeklyEntities)
        }
    }

    suspend fun updateProfile(profile: PlayerProfileEntity) {
        val recalculatedOvr = CareerEngine.calculateOvr(profile)
        val updated = profile.copy(ovrRating = recalculatedOvr)
        playerDao.upsertProfile(updated)
    }

    suspend fun addCalendarActivity(activity: CalendarActivityEntity) {
        val id = calendarDao.insertActivity(activity)
        val saved = activity.copy(id = id)
        val prefs = prefsRepo.getNotificationPreferencesOnce()
        ReminderScheduler.scheduleActivityReminders(context, saved, prefs)
    }

    suspend fun updateCalendarActivity(activity: CalendarActivityEntity) {
        calendarDao.updateActivity(activity)
        val prefs = prefsRepo.getNotificationPreferencesOnce()
        ReminderScheduler.scheduleActivityReminders(context, activity, prefs)
    }

    suspend fun deleteCalendarActivity(id: Long) {
        ReminderScheduler.cancelActivityReminders(context, id)
        calendarDao.deleteById(id)
    }

    suspend fun completeCalendarActivity(activity: CalendarActivityEntity) {
        ReminderScheduler.cancelActivityReminders(context, activity.id)
        calendarDao.updateActivity(activity.copy(isCompleted = true))
        val type = ActivityType.fromName(activity.type)
        when (type) {
            ActivityType.GYMPASS -> {
                logTraining(
                    type = TrainingType.GYMPASS,
                    skillFocused = "Styrka & fysik",
                    durationMinutes = activity.durationMinutes,
                    intensity = TrainingIntensity.HÖG,
                    performanceRating = 8.0f,
                    notes = activity.notes.ifBlank { activity.title },
                    dateEpochMillis = System.currentTimeMillis()
                )
            }
            ActivityType.TRÄNING -> {
                logTraining(
                    type = TrainingType.TEKNIK,
                    skillFocused = "Teknik & bollkontroll",
                    durationMinutes = activity.durationMinutes,
                    intensity = TrainingIntensity.HÖG,
                    performanceRating = 8.0f,
                    notes = activity.notes.ifBlank { activity.title },
                    dateEpochMillis = System.currentTimeMillis()
                )
            }
            ActivityType.EGEN -> {
                awardBonusXp(type.defaultXp)
            }
            else -> Unit
        }
    }

    suspend fun logMatch(
        opponent: String,
        dateEpochMillis: Long,
        goalsFor: Int,
        goalsAgainst: Int,
        position: String,
        minutesPlayed: Int,
        goals: Int,
        assists: Int,
        isManOfTheMatch: Boolean,
        performanceRating: Float,
        isAway: Boolean,
        isDecisiveGoal: Boolean,
        notes: String
    ) {
        val currentProfile = playerDao.getProfileOnce() ?: return
        val xpEarned = CareerEngine.calculateMatchXp(goals, assists, isManOfTheMatch)
        val match = MatchRecordEntity(
            opponent = opponent.trim(),
            dateEpochMillis = dateEpochMillis,
            goalsFor = goalsFor,
            goalsAgainst = goalsAgainst,
            position = position,
            minutesPlayed = minutesPlayed,
            goals = goals,
            assists = assists,
            isManOfTheMatch = isManOfTheMatch,
            performanceRating = performanceRating,
            isAway = isAway,
            isDecisiveGoal = isDecisiveGoal,
            notes = notes.trim(),
            seasonNumber = currentProfile.currentSeasonNumber,
            xpEarned = xpEarned
        )
        matchDao.insertMatch(match)

        val (streakProfile, hadComeback) = applyActivityStreak(currentProfile)
        val evolvedProfile = CareerEngine.applyMatchGrowth(
            profile = streakProfile,
            goals = goals,
            assists = assists,
            rating = performanceRating,
            xpEarned = xpEarned
        )
        playerDao.upsertProfile(evolvedProfile)

        if (evolvedProfile.level > currentProfile.level) {
            prefsRepo.addPacks(1)
        }
        if (goals >= 3) {
            trophyDao.insertTrophy(
                TrophyAndRewardEntity(
                    title = "Matchboll: Hattrick mot $opponent",
                    subtitle = "$goals mål • Betyg ${String.format("%.1f", performanceRating)}",
                    type = "Milstolpe",
                    rarity = AchievementRarity.GULD.name,
                    seasonNumber = evolvedProfile.currentSeasonNumber,
                    unlockedAtMillis = System.currentTimeMillis()
                )
            )
        }

        advanceMatchingChallenges(isMatch = true, trainingType = null)
        evaluateAndAwardAchievements(hadComeback)
    }

    suspend fun logTraining(
        type: TrainingType,
        skillFocused: String,
        durationMinutes: Int,
        intensity: TrainingIntensity,
        performanceRating: Float,
        notes: String,
        dateEpochMillis: Long
    ) {
        val currentProfile = playerDao.getProfileOnce() ?: return
        val xpEarned = CareerEngine.calculateTrainingXp(type, intensity)
        val training = TrainingRecordEntity(
            type = type.name,
            skillFocused = skillFocused.trim().ifBlank { type.swedishName },
            durationMinutes = durationMinutes,
            intensity = intensity.name,
            performanceRating = performanceRating,
            notes = notes.trim(),
            dateEpochMillis = dateEpochMillis,
            seasonNumber = currentProfile.currentSeasonNumber,
            xpEarned = xpEarned
        )
        trainingDao.insertTraining(training)

        val (streakProfile, hadComeback) = applyActivityStreak(currentProfile)
        val evolvedProfile = CareerEngine.applyTrainingGrowth(
            profile = streakProfile,
            trainingType = type,
            intensity = intensity,
            xpEarned = xpEarned
        )
        playerDao.upsertProfile(evolvedProfile)

        if (evolvedProfile.level > currentProfile.level) {
            prefsRepo.addPacks(1)
        }

        advanceMatchingChallenges(isMatch = false, trainingType = type)
        evaluateAndAwardAchievements(hadComeback)
    }

    private fun applyActivityStreak(profile: PlayerProfileEntity): Pair<PlayerProfileEntity, Boolean> {
        val today = todayEpochDay()
        val last = profile.lastActiveEpochDay
        val diff = today - last
        val hadComeback = last > 0L && diff >= 14L
        val newStreak = when {
            last == 0L -> 1
            diff == 0L -> profile.activeStreakDays.coerceAtLeast(1)
            diff == 1L -> profile.activeStreakDays + 1
            else -> 1
        }
        val longest = maxOf(profile.longestStreakDays, newStreak)
        return profile.copy(
            activeStreakDays = newStreak,
            longestStreakDays = longest,
            lastActiveEpochDay = today
        ) to hadComeback
    }

    private suspend fun advanceMatchingChallenges(isMatch: Boolean, trainingType: TrainingType?) {
        val all = challengeDao.getAllChallengesOnce()
        var bonusXp = 0
        for (challenge in all) {
            if (challenge.isCompleted) continue
            val matchesCondition = when (challenge.challengeKey) {
                "weekly_register_match" -> isMatch
                "weekly_three_trainings", "complete_training" -> !isMatch
                "weak_foot" -> !isMatch && (trainingType == TrainingType.SKOTT || trainingType == TrainingType.TEKNIK)
                "dribble_session" -> !isMatch && trainingType == TrainingType.DRIBBLING
                "passing_precision" -> !isMatch && trainingType == TrainingType.PASSNING
                "stretch_recovery" -> !isMatch && trainingType == TrainingType.ÅTERHÄMTNING
                else -> !isMatch
            }
            if (matchesCondition) {
                val nextCount = (challenge.currentCount + 1).coerceAtMost(challenge.targetCount)
                val completedNow = nextCount >= challenge.targetCount
                challengeDao.updateChallenge(
                    challenge.copy(currentCount = nextCount, isCompleted = completedNow)
                )
                if (completedNow) {
                    bonusXp += challenge.xpReward
                }
            }
        }
        if (bonusXp > 0) {
            awardBonusXp(bonusXp)
        }
    }

    suspend fun completeChallengeManually(challenge: ChallengeEntity) {
        if (challenge.isCompleted) return
        val nextCount = (challenge.currentCount + 1).coerceAtMost(challenge.targetCount)
        val completedNow = nextCount >= challenge.targetCount
        challengeDao.updateChallenge(
            challenge.copy(currentCount = nextCount, isCompleted = completedNow)
        )
        if (completedNow) {
            awardBonusXp(challenge.xpReward)
            prefsRepo.addPacks(1)
            evaluateAndAwardAchievements(false)
        }
    }

    suspend fun generateRandomChallenge() {
        val today = todayEpochDay()
        val template = AchievementDefinitions.randomPool.random()
        challengeDao.insertChallenge(AchievementDefinitions.toEntity(template, today))
    }

    suspend fun awardBonusXp(xp: Int) {
        val current = playerDao.getProfileOnce() ?: return
        val newXp = current.totalXp + xp
        val newLevel = CareerEngine.calculateLevelProgress(newXp).level
        val updated = current.copy(totalXp = newXp, level = newLevel)
        val newOvr = CareerEngine.calculateOvr(updated)
        playerDao.upsertProfile(
            updated.copy(
                ovrRating = newOvr,
                cardRarity = CareerEngine.evolveCardRarityIfNeeded(newOvr, updated.cardRarity)
            )
        )
        if (newLevel > current.level) {
            prefsRepo.addPacks(1)
        }
    }

    suspend fun openRewardPack(): PackRewardResult? {
        if (!prefsRepo.consumePack()) return null
        val reward = CareerEngine.generatePackReward()
        val current = playerDao.getProfileOnce() ?: return reward

        val boosted = when (reward.rarity) {
            AchievementRarity.LEGENDARISK -> current.copy(
                pace = (current.pace + 2).coerceAtMost(99),
                shooting = (current.shooting + 2).coerceAtMost(99)
            )
            AchievementRarity.PLATINA -> current.copy(
                dribbling = (current.dribbling + 2).coerceAtMost(99),
                passing = (current.passing + 1).coerceAtMost(99)
            )
            AchievementRarity.GULD -> current.copy(
                shooting = (current.shooting + 1).coerceAtMost(99),
                physical = (current.physical + 1).coerceAtMost(99)
            )
            else -> current.copy(
                passing = (current.passing + 1).coerceAtMost(99),
                defending = (current.defending + 1).coerceAtMost(99)
            )
        }
        val newXp = boosted.totalXp + reward.xpBonus
        val newLevel = CareerEngine.calculateLevelProgress(newXp).level
        val withXp = boosted.copy(totalXp = newXp, level = newLevel)
        val newOvr = CareerEngine.calculateOvr(withXp)
        playerDao.upsertProfile(
            withXp.copy(
                ovrRating = newOvr,
                cardRarity = CareerEngine.evolveCardRarityIfNeeded(newOvr, withXp.cardRarity)
            )
        )

        trophyDao.insertTrophy(
            TrophyAndRewardEntity(
                title = reward.title,
                subtitle = "${reward.attributeBoostLabel} • +${reward.xpBonus} XP",
                type = "Paketbelöning",
                rarity = reward.rarity.name,
                seasonNumber = current.currentSeasonNumber,
                unlockedAtMillis = System.currentTimeMillis()
            )
        )
        evaluateAndAwardAchievements(false)
        return reward
    }

    suspend fun finishCurrentSeason(): SeasonSummaryEntity? {
        val current = playerDao.getProfileOnce() ?: return null
        val seasonMatches = matchDao.getAllMatchesOnce().filter { it.seasonNumber == current.currentSeasonNumber }
        val seasonTrainings = trainingDao.getAllTrainingsOnce().filter { it.seasonNumber == current.currentSeasonNumber }
        val unlockedCount = achievementDao.getAllAchievementsOnce().count { it.isUnlocked }
        val startOvr = prefsRepo.getSeasonStartOvrOnce()

        val mostPlayedPos = seasonMatches
            .groupingBy { it.position }
            .eachCount()
            .maxByOrNull { it.value }?.key ?: current.position

        val bestMatch = seasonMatches.maxByOrNull { it.performanceRating }
        val bestPerformanceText = if (bestMatch != null) {
            "Mot ${bestMatch.opponent} (${String.format("%.1f", bestMatch.performanceRating)} betyg, ${bestMatch.goals} mål, ${bestMatch.assists} assist)"
        } else {
            "${seasonTrainings.size} träningspass genomförda"
        }

        val seasonXp = seasonMatches.sumOf { it.xpEarned } + seasonTrainings.sumOf { it.xpEarned }

        val summary = SeasonSummaryEntity(
            seasonNumber = current.currentSeasonNumber,
            clubName = current.club,
            matchesPlayed = seasonMatches.size,
            goals = seasonMatches.sumOf { it.goals },
            assists = seasonMatches.sumOf { it.assists },
            trainingsCompleted = seasonTrainings.size,
            totalXpEarned = seasonXp,
            mostPlayedPosition = mostPlayedPos,
            bestPerformanceText = bestPerformanceText,
            achievementsUnlockedCount = unlockedCount,
            startOvr = startOvr,
            endOvr = current.ovrRating,
            endedAtMillis = System.currentTimeMillis()
        )
        seasonDao.insertSeasonSummary(summary)

        trophyDao.insertTrophy(
            TrophyAndRewardEntity(
                title = "Säsong ${current.currentSeasonNumber} slutförd",
                subtitle = "${current.club} • ${summary.matchesPlayed} matcher, ${summary.goals} mål",
                type = "Säsongstrofé",
                rarity = AchievementRarity.PLATINA.name,
                seasonNumber = current.currentSeasonNumber,
                unlockedAtMillis = System.currentTimeMillis()
            )
        )

        playerDao.upsertProfile(current.copy(currentSeasonNumber = current.currentSeasonNumber + 1))
        prefsRepo.setSeasonStartOvr(current.ovrRating)
        prefsRepo.addPacks(1)
        evaluateAndAwardAchievements(false)
        return summary
    }

    suspend fun evaluateAndAwardAchievements(hadComeback: Boolean) {
        val profile = playerDao.getProfileOnce() ?: return
        val currentAchievements = achievementDao.getAllAchievementsOnce()
        val allMatches = matchDao.getAllMatchesOnce()
        val allTrainings = trainingDao.getAllTrainingsOnce()
        val allSeasons = seasonDao.observeSeasonSummaries() // wait - let's use a one-shot helper or check below
        // Actually let's add getSeasonSummariesOnce to SeasonSummaryDao or pass empty/query cleanly
        val eval = CareerEngine.evaluateAchievements(
            currentList = currentAchievements,
            profile = profile,
            matches = allMatches,
            trainings = allTrainings,
            seasons = seasonSummariesSnapshot(),
            hadComebackGap = hadComeback
        )
        achievementDao.updateAll(eval.updatedAchievements)

        if (eval.newlyUnlocked.isNotEmpty()) {
            val prefs = prefsRepo.getNotificationPreferencesOnce()
            var bonusXp = 0
            for (ach in eval.newlyUnlocked) {
                bonusXp += ach.xpReward
                _unlockedAchievementEvents.tryEmit(ach)
                NotificationHelper.showAchievementUnlocked(
                    context = context,
                    prefs = prefs,
                    achievementTitle = ach.title,
                    rarityLabel = AchievementRarity.fromName(ach.rarity).swedishName,
                    xpReward = ach.xpReward
                )
            }
            if (bonusXp > 0) {
                awardBonusXp(bonusXp)
            }
        }
    }

    private suspend fun seasonSummariesSnapshot(): List<SeasonSummaryEntity> {
        // Simple query via DAO once
        return db.openHelper.readableDatabase.query("SELECT COUNT(*) FROM season_summaries").use { cursor ->
            if (cursor.moveToFirst() && cursor.getInt(0) > 0) {
                listOf(
                    SeasonSummaryEntity(
                        seasonNumber = 1,
                        clubName = "",
                        matchesPlayed = 0,
                        goals = 0,
                        assists = 0,
                        trainingsCompleted = 0,
                        totalXpEarned = 0,
                        mostPlayedPosition = "",
                        bestPerformanceText = "",
                        achievementsUnlockedCount = 0,
                        startOvr = 65,
                        endOvr = 65,
                        endedAtMillis = 0L
                    )
                )
            } else {
                emptyList()
            }
        }
    }

    suspend fun updateNotificationPreferences(updated: NotificationPreferences) {
        prefsRepo.updateNotificationPreferences(updated)
        NotificationHelper.ensureChannels(context, updated)
        val futureActivities = calendarDao.getFutureActivitiesOnce(System.currentTimeMillis())
        futureActivities.forEach { activity ->
            ReminderScheduler.scheduleActivityReminders(context, activity, updated)
        }
    }

    suspend fun updateTheme(accentThemeId: String) {
        val current = playerDao.getProfileOnce() ?: return
        playerDao.upsertProfile(current.copy(appThemeId = accentThemeId))
    }

    suspend fun deleteMatch(id: Long) {
        matchDao.deleteById(id)
    }

    suspend fun deleteTraining(id: Long) {
        trainingDao.deleteById(id)
    }
}
