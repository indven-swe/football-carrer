package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.FootballCareerApp
import com.example.data.local.AchievementEntity
import com.example.data.local.CalendarActivityEntity
import com.example.data.local.ChallengeEntity
import com.example.data.local.MatchRecordEntity
import com.example.data.local.NotificationPreferences
import com.example.data.local.PlayerProfileEntity
import com.example.data.local.SeasonSummaryEntity
import com.example.data.local.TrainingRecordEntity
import com.example.data.local.TrophyAndRewardEntity
import com.example.domain.ActivityType
import com.example.domain.CareerEngine
import com.example.domain.LevelProgress
import com.example.domain.PackRewardResult
import com.example.domain.PersonalRecord
import com.example.domain.TrainingIntensity
import com.example.domain.TrainingType
import com.example.notifications.NotificationHelper
import com.example.notifications.SoundPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CareerUiState(
    val isLoading: Boolean = true,
    val profile: PlayerProfileEntity? = null,
    val levelProgress: LevelProgress = CareerEngine.calculateLevelProgress(0),
    val activities: List<CalendarActivityEntity> = emptyList(),
    val matches: List<MatchRecordEntity> = emptyList(),
    val trainings: List<TrainingRecordEntity> = emptyList(),
    val achievements: List<AchievementEntity> = emptyList(),
    val challenges: List<ChallengeEntity> = emptyList(),
    val trophies: List<TrophyAndRewardEntity> = emptyList(),
    val seasonSummaries: List<SeasonSummaryEntity> = emptyList(),
    val notificationPrefs: NotificationPreferences = NotificationPreferences(),
    val unopenedPacks: Int = 0,
    val personalRecords: List<PersonalRecord> = emptyList(),
    val nowMillis: Long = System.currentTimeMillis()
) {
    val nextActivity: CalendarActivityEntity?
        get() = activities.firstOrNull { !it.isCompleted && it.startTimeMillis > nowMillis }

    val nextMatch: CalendarActivityEntity?
        get() = activities.firstOrNull {
            !it.isCompleted && it.startTimeMillis > nowMillis &&
                (it.type == ActivityType.MATCH.name || it.type == ActivityType.TURNERING.name)
        }

    val nextTraining: CalendarActivityEntity?
        get() = activities.firstOrNull {
            !it.isCompleted && it.startTimeMillis > nowMillis &&
                (it.type == ActivityType.TRÄNING.name || it.type == ActivityType.GYMPASS.name)
        }
}

class CareerViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = (application as FootballCareerApp).careerRepository

    private val _nowMillis = MutableStateFlow(System.currentTimeMillis())

    private val _recentUnlockedAchievement = MutableStateFlow<AchievementEntity?>(null)
    val recentUnlockedAchievement: StateFlow<AchievementEntity?> = _recentUnlockedAchievement.asStateFlow()

    private val _lastPackReward = MutableStateFlow<PackRewardResult?>(null)
    val lastPackReward: StateFlow<PackRewardResult?> = _lastPackReward.asStateFlow()

    private val _lastSeasonSummary = MutableStateFlow<SeasonSummaryEntity?>(null)
    val lastSeasonSummary: StateFlow<SeasonSummaryEntity?> = _lastSeasonSummary.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    private val baseDataFlow = combine(
        repo.playerProfile,
        repo.calendarActivities,
        repo.matches,
        repo.trainings,
        repo.achievements
    ) { profile, activities, matches, trainings, achievements ->
        BaseData(profile, activities, matches, trainings, achievements)
    }

    private val extraDataFlow = combine(
        repo.challenges,
        repo.trophies,
        repo.seasonSummaries,
        repo.notificationPreferences,
        repo.unopenedPacksCount
    ) { challenges, trophies, seasons, notifPrefs, packs ->
        ExtraData(challenges, trophies, seasons, notifPrefs, packs)
    }

    val uiState: StateFlow<CareerUiState> = combine(
        baseDataFlow,
        extraDataFlow,
        _nowMillis
    ) { base, extra, now ->
        val profile = base.profile
        val levelProgress = CareerEngine.calculateLevelProgress(profile?.totalXp ?: 0)
        val records = if (profile != null) {
            CareerEngine.computePersonalRecords(profile, base.matches, base.trainings)
        } else {
            emptyList()
        }
        CareerUiState(
            isLoading = profile == null,
            profile = profile,
            levelProgress = levelProgress,
            activities = base.activities,
            matches = base.matches,
            trainings = base.trainings,
            achievements = base.achievements,
            challenges = extra.challenges,
            trophies = extra.trophies,
            seasonSummaries = extra.seasons,
            notificationPrefs = extra.notifPrefs,
            unopenedPacks = extra.packs,
            personalRecords = records,
            nowMillis = now
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CareerUiState()
    )

    init {
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                _nowMillis.value = System.currentTimeMillis()
            }
        }
        viewModelScope.launch {
            repo.unlockedAchievementEvents.collect { ach ->
                _recentUnlockedAchievement.value = ach
                SoundPlayer.playPreview(getApplication(), "achievement_fanfare")
            }
        }
    }

    fun dismissAchievementBanner() {
        _recentUnlockedAchievement.value = null
    }

    fun clearFeedback() {
        _feedbackMessage.value = null
    }

    fun dismissPackReward() {
        _lastPackReward.value = null
    }

    fun dismissSeasonSummary() {
        _lastSeasonSummary.value = null
    }

    fun updateProfile(profile: PlayerProfileEntity) {
        viewModelScope.launch {
            repo.updateProfile(profile)
            _feedbackMessage.value = "Spelarprofil och spelarkort uppdaterat!"
        }
    }

    fun updateAppTheme(themeId: String) {
        viewModelScope.launch {
            repo.updateTheme(themeId)
        }
    }

    fun addActivity(activity: CalendarActivityEntity) {
        viewModelScope.launch {
            repo.addCalendarActivity(activity)
            _feedbackMessage.value = "Aktivitet tillagd i kalendern och påminnelser schemalagda."
        }
    }

    fun deleteActivity(id: Long) {
        viewModelScope.launch {
            repo.deleteCalendarActivity(id)
            _feedbackMessage.value = "Aktivitet borttagen."
        }
    }

    fun completeActivity(activity: CalendarActivityEntity) {
        viewModelScope.launch {
            repo.completeCalendarActivity(activity)
            _feedbackMessage.value = "Aktivitet slutförd! XP tilldelat."
        }
    }

    fun logMatch(
        opponent: String,
        dateEpochMillis: Long,
        goalsFor: Int,
        goalsAgainst: Int,
        position: String,
        minutesPlayed: Int,
        goals: Int,
        assists: Int,
        isManOfTheMatch: Boolean,
        performanceRating: Float,
        isAway: Boolean,
        isDecisiveGoal: Boolean,
        notes: String
    ) {
        viewModelScope.launch {
            repo.logMatch(
                opponent = opponent,
                dateEpochMillis = dateEpochMillis,
                goalsFor = goalsFor,
                goalsAgainst = goalsAgainst,
                position = position,
                minutesPlayed = minutesPlayed,
                goals = goals,
                assists = assists,
                isManOfTheMatch = isManOfTheMatch,
                performanceRating = performanceRating,
                isAway = isAway,
                isDecisiveGoal = isDecisiveGoal,
                notes = notes
            )
            val xp = CareerEngine.calculateMatchXp(goals, assists, isManOfTheMatch)
            _feedbackMessage.value = "Match mot $opponent sparad! +$xp XP"
        }
    }

    fun logTraining(
        type: TrainingType,
        skillFocused: String,
        durationMinutes: Int,
        intensity: TrainingIntensity,
        performanceRating: Float,
        notes: String,
        dateEpochMillis: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            repo.logTraining(
                type = type,
                skillFocused = skillFocused,
                durationMinutes = durationMinutes,
                intensity = intensity,
                performanceRating = performanceRating,
                notes = notes,
                dateEpochMillis = dateEpochMillis
            )
            val xp = CareerEngine.calculateTrainingXp(type, intensity)
            _feedbackMessage.value = "Träning sparad! +$xp XP"
        }
    }

    fun completeChallenge(challenge: ChallengeEntity) {
        viewModelScope.launch {
            repo.completeChallengeManually(challenge)
            _feedbackMessage.value = "Utmaning slutförd! +${challenge.xpReward} XP & 1 Belöningspaket!"
        }
    }

    fun generateRandomChallenge() {
        viewModelScope.launch {
            repo.generateRandomChallenge()
            _feedbackMessage.value = "Ny slumpmässig fotbollsutmaning tillagd!"
        }
    }

    fun openRewardPack() {
        viewModelScope.launch {
            val result = repo.openRewardPack()
            if (result != null) {
                _lastPackReward.value = result
                SoundPlayer.playPreview(getApplication(), "achievement_fanfare")
            } else {
                _feedbackMessage.value = "Inga oöppnade paket just nu. Slutför utmaningar eller gå upp i nivå!"
            }
        }
    }

    fun finishSeason() {
        viewModelScope.launch {
            val summary = repo.finishCurrentSeason()
            if (summary != null) {
                _lastSeasonSummary.value = summary
                SoundPlayer.playPreview(getApplication(), "achievement_fanfare")
            }
        }
    }

    fun updateNotificationPrefs(prefs: NotificationPreferences) {
        viewModelScope.launch {
            repo.updateNotificationPreferences(prefs)
        }
    }

    fun previewSound(soundId: String) {
        SoundPlayer.playPreview(getApplication(), soundId)
    }

    fun sendTestNotification(isMatch: Boolean) {
        val prefs = uiState.value.notificationPrefs
        val context = getApplication<Application>()
        if (prefs.vibrationEnabled) {
            SoundPlayer.vibratePulse(context)
        }
        NotificationHelper.showActivityReminder(
            context = context,
            prefs = prefs,
            notificationId = if (isMatch) 9001 else 9002,
            activityTitle = if (isMatch) "Testmatch vs Rivalerna FC" else "Testträning: Teknik & avslut",
            activityType = if (isMatch) ActivityType.MATCH else ActivityType.TRÄNING,
            minutesBefore = 15,
            timeFormatted = "18:30",
            location = "Huvudarenan"
        )
        _feedbackMessage.value = "Testnotis skickad!"
    }

    fun deleteMatch(id: Long) {
        viewModelScope.launch { repo.deleteMatch(id) }
    }

    fun deleteTraining(id: Long) {
        viewModelScope.launch { repo.deleteTraining(id) }
    }

    private data class BaseData(
        val profile: PlayerProfileEntity?,
        val activities: List<CalendarActivityEntity>,
        val matches: List<MatchRecordEntity>,
        val trainings: List<TrainingRecordEntity>,
        val achievements: List<AchievementEntity>
    )

    private data class ExtraData(
        val challenges: List<ChallengeEntity>,
        val trophies: List<TrophyAndRewardEntity>,
        val seasons: List<SeasonSummaryEntity>,
        val notifPrefs: NotificationPreferences,
        val packs: Int
    )
}
