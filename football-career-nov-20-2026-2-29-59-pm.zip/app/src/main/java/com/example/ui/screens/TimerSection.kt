package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.components.SwedishFormatters
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState
import com.example.ui.viewmodel.MatchHalfPhase
import com.example.ui.viewmodel.TimerUiState
import com.example.ui.viewmodel.TimerViewModel

@Composable
fun TimerSection(
    careerState: CareerUiState,
    timerState: TimerUiState,
    timerViewModel: TimerViewModel,
    onSaveStopwatchAsTraining: (Int) -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    var customMinsInput by remember { mutableIntStateOf(5) }
    var customSecsInput by remember { mutableIntStateOf(0) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Live-nedräkning till nästa match & nästa träning
        SectionHeader(title = "Kommande nedräkningar", subtitle = "Uppdateras varje sekund")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StadiumCard(modifier = Modifier.weight(1f), borderColor = ChampionGold.copy(alpha = 0.5f)) {
                Text("NÄSTA MATCH", style = MaterialTheme.typography.labelSmall, color = ChampionGold)
                Spacer(Modifier.height(4.dp))
                val nextMatch = careerState.nextMatch
                if (nextMatch != null) {
                    Text(
                        text = SwedishFormatters.formatCountdown(nextMatch.startTimeMillis, careerState.nowMillis),
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(text = nextMatch.title, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                } else {
                    Text("Ej planerad", style = MaterialTheme.typography.titleMedium, color = TextSecondary)
                }
            }

            StadiumCard(modifier = Modifier.weight(1f), borderColor = primary.copy(alpha = 0.5f)) {
                Text("NÄSTA TRÄNING", style = MaterialTheme.typography.labelSmall, color = primary)
                Spacer(Modifier.height(4.dp))
                val nextTraining = careerState.nextTraining
                if (nextTraining != null) {
                    Text(
                        text = SwedishFormatters.formatCountdown(nextTraining.startTimeMillis, careerState.nowMillis),
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimary
                    )
                    Text(text = nextTraining.title, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                } else {
                    Text("Ej planerad", style = MaterialTheme.typography.titleMedium, color = TextSecondary)
                }
            }
        }

        // 2. Matchtimer med två halvlekar
        StadiumCard(borderColor = ChampionGold.copy(alpha = 0.6f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.SportsSoccer, contentDescription = null, tint = ChampionGold)
                    Spacer(Modifier.width(8.dp))
                    Text("MATCHTIMER (2 HALVLEKAR)", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                }
                Text(
                    text = timerState.matchPhase.swedishLabel.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = ChampionGold
                )
            }

            Spacer(Modifier.height(10.dp))
            Text(
                text = SwedishFormatters.formatSecondsClock(timerState.matchElapsedSeconds),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
                color = ChampionGold,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Text(
                text = "Halvlekslängd: ${timerState.matchHalfMinutes} min • Full tid: ${timerState.matchHalfMinutes * 2} min",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                listOf(15, 30, 45).forEach { mins ->
                    FilterChip(
                        selected = timerState.matchHalfMinutes == mins,
                        onClick = { timerViewModel.setMatchHalfLength(mins) },
                        label = { Text("${mins}m") }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { timerViewModel.toggleMatchTimer() },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("match_timer_toggle_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ChampionGold, contentColor = ObsidianBlack)
                ) {
                    Icon(
                        imageVector = if (timerState.matchRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = when {
                            timerState.matchRunning -> "Pausa"
                            timerState.matchElapsedSeconds > 0 && timerState.matchPhase != MatchHalfPhase.FULLTIME -> "Återuppta"
                            else -> "Starta"
                        }
                    )
                }
                OutlinedButton(
                    onClick = { timerViewModel.advanceMatchPhase() },
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Nästa halvlek")
                }
                OutlinedButton(
                    onClick = { timerViewModel.resetMatchTimer() },
                    contentPadding = PaddingValues(horizontal = 10.dp)
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Återställ matchtimer")
                }
            }
        }

        // 3. Träningstidtagarur
        StadiumCard(borderColor = primary.copy(alpha = 0.6f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Timer, contentDescription = null, tint = primary)
                Spacer(Modifier.width(8.dp))
                Text("TIDTAGARUR FÖR TRÄNING", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = SwedishFormatters.formatStopwatch(timerState.stopwatchMillis),
                style = MaterialTheme.typography.displayLarge.copy(fontSize = 46.sp),
                color = primary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { timerViewModel.toggleStopwatch() },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("stopwatch_toggle_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Icon(
                        imageVector = if (timerState.stopwatchRunning) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        when {
                            timerState.stopwatchRunning -> "Pausa"
                            timerState.stopwatchMillis > 0L -> "Återuppta"
                            else -> "Starta"
                        }
                    )
                }
                OutlinedButton(
                    onClick = { timerViewModel.lapStopwatch() },
                    enabled = timerState.stopwatchMillis > 0L
                ) {
                    Icon(Icons.Filled.Flag, contentDescription = "Varvtid")
                    Spacer(Modifier.width(4.dp))
                    Text("Varv")
                }
                OutlinedButton(onClick = { timerViewModel.resetStopwatch() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Återställ")
                }
            }

            if (timerState.stopwatchLaps.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                timerState.stopwatchLaps.take(3).forEachIndexed { idx, lapMillis ->
                    Text(
                        text = "Varv ${timerState.stopwatchLaps.size - idx}: ${SwedishFormatters.formatStopwatch(lapMillis)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            if (timerState.stopwatchMillis >= 60_000L) {
                Spacer(Modifier.height(8.dp))
                val mins = (timerState.stopwatchMillis / 60_000L).toInt().coerceAtLeast(1)
                OutlinedButton(
                    onClick = { onSaveStopwatchAsTraining(mins) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Spara som träningspass ($mins min)")
                }
            }
        }

        // 4. Paustimer
        StadiumCard {
            Text("PAUSTIMER & INTERVALL", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            Text(
                text = SwedishFormatters.formatSecondsClock(timerState.pauseRemainingSeconds),
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
            ) {
                listOf(30 to "30s", 60 to "1m", 90 to "90s", 180 to "3m", 900 to "15m").forEach { (sec, label) ->
                    FilterChip(
                        selected = timerState.pausePresetSeconds == sec,
                        onClick = { timerViewModel.setPausePreset(sec) },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { timerViewModel.togglePauseTimer() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (timerState.pauseRunning) "Pausa" else "Starta")
                }
                OutlinedButton(onClick = { timerViewModel.resetPauseTimer() }) {
                    Text("Återställ")
                }
            }
        }

        // 5. Egen anpassningsbar timer
        StadiumCard {
            Text("EGEN ANPASSNINGSBAR TIMER", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            Text(
                text = SwedishFormatters.formatSecondsClock(timerState.customRemainingSeconds),
                style = MaterialTheme.typography.displayMedium,
                color = primary,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        onClick = {
                            customMinsInput = (customMinsInput - 1).coerceAtLeast(0)
                            timerViewModel.setCustomDuration(customMinsInput, customSecsInput)
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) { Text("-1m") }
                    Text("${customMinsInput}m", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                    OutlinedButton(
                        onClick = {
                            customMinsInput = (customMinsInput + 1).coerceAtMost(120)
                            timerViewModel.setCustomDuration(customMinsInput, customSecsInput)
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) { Text("+1m") }
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    OutlinedButton(
                        onClick = {
                            customSecsInput = (customSecsInput - 15 + 60) % 60
                            timerViewModel.setCustomDuration(customMinsInput, customSecsInput)
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) { Text("-15s") }
                    Text("${customSecsInput}s", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = TextPrimary)
                    OutlinedButton(
                        onClick = {
                            customSecsInput = (customSecsInput + 15) % 60
                            timerViewModel.setCustomDuration(customMinsInput, customSecsInput)
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) { Text("+15s") }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { timerViewModel.toggleCustomTimer() },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text(
                        when {
                            timerState.customRunning -> "Pausa"
                            timerState.customRemainingSeconds < timerState.customTotalSeconds -> "Återuppta"
                            else -> "Starta"
                        }
                    )
                }
                OutlinedButton(onClick = { timerViewModel.resetCustomTimer() }) {
                    Text("Återställ")
                }
            }
        }
    }
}
