package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.domain.PlayerPosition
import com.example.domain.TrainingIntensity
import com.example.domain.TrainingType
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Calendar
import kotlin.math.roundToInt

@Composable
fun LogMatchDialog(
    defaultPosition: String,
    onSave: (
        opponent: String,
        dateMillis: Long,
        goalsFor: Int,
        goalsAgainst: Int,
        position: String,
        minutesPlayed: Int,
        goals: Int,
        assists: Int,
        isMotm: Boolean,
        rating: Float,
        isAway: Boolean,
        isDecisive: Boolean,
        notes: String
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var opponent by remember { mutableStateOf("") }
    var goalsFor by remember { mutableIntStateOf(2) }
    var goalsAgainst by remember { mutableIntStateOf(1) }
    var position by remember { mutableStateOf(defaultPosition) }
    var minutesPlayedText by remember { mutableStateOf("90") }
    var goals by remember { mutableIntStateOf(1) }
    var assists by remember { mutableIntStateOf(0) }
    var isMotm by remember { mutableStateOf(false) }
    var isAway by remember { mutableStateOf(false) }
    var isDecisive by remember { mutableStateOf(false) }
    var rating by remember { mutableFloatStateOf(7.8f) }
    var notes by remember { mutableStateOf("") }

    val primary = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CarbonSurface)
                .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "REGISTRERA MATCH",
                style = MaterialTheme.typography.headlineMedium,
                color = primary
            )

            OutlinedTextField(
                value = opponent,
                onValueChange = { opponent = it },
                label = { Text("Motståndare") },
                placeholder = { Text("t.ex. Hammarby IF U19") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("match_opponent_input")
            )

            Text("Resultat (Ditt lag – Motståndare)", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StepperField("Våra mål", goalsFor, onChange = { goalsFor = it.coerceAtLeast(0) })
                Text("-", style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
                StepperField("Insläppta", goalsAgainst, onChange = { goalsAgainst = it.coerceAtLeast(0) })
            }

            Text("Position", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PlayerPosition.entries.forEach { pos ->
                    FilterChip(
                        selected = position == pos.code,
                        onClick = { position = pos.code },
                        label = { Text(pos.code) }
                    )
                }
            }

            OutlinedTextField(
                value = minutesPlayedText,
                onValueChange = { minutesPlayedText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Spelade minuter") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                StepperField("Dina mål", goals, onChange = { goals = it.coerceAtLeast(0) })
                StepperField("Dina assist", assists, onChange = { assists = it.coerceAtLeast(0) })
            }

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Prestationsbetyg", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text(
                        text = String.format("%.1f / 10", rating),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = primary
                    )
                }
                Slider(
                    value = rating,
                    onValueChange = { rating = (it * 10f).roundToInt() / 10f },
                    valueRange = 1.0f..10.0f
                )
            }

            SwitchRowCompact("Matchens spelare (+50 XP)", isMotm) { isMotm = it }
            SwitchRowCompact("Bortamatch", isAway) { isAway = it }
            SwitchRowCompact("Avgörande mål", isDecisive) { isDecisive = it }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Anteckningar") },
                placeholder = { Text("Hur kändes matchen?") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text("Avbryt")
                }
                Button(
                    onClick = {
                        val safeOpponent = opponent.trim().ifBlank { "Motståndare FC" }
                        val mins = minutesPlayedText.toIntOrNull()?.coerceIn(1, 130) ?: 90
                        onSave(
                            safeOpponent,
                            System.currentTimeMillis(),
                            goalsFor,
                            goalsAgainst,
                            position,
                            mins,
                            goals,
                            assists,
                            isMotm,
                            rating,
                            isAway,
                            isDecisive,
                            notes
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_match_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("SPARA MATCH", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun LogTrainingDialog(
    initialDurationMinutes: Int = 60,
    onSave: (
        type: TrainingType,
        skillFocused: String,
        durationMinutes: Int,
        intensity: TrainingIntensity,
        rating: Float,
        notes: String,
        dateMillis: Long
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(TrainingType.TEKNIK) }
    var skillFocused by remember { mutableStateOf("Förstatouch & vändningar") }
    var durationText by remember { mutableStateOf(initialDurationMinutes.toString()) }
    var intensity by remember { mutableStateOf(TrainingIntensity.HÖG) }
    var rating by remember { mutableFloatStateOf(8.0f) }
    var notes by remember { mutableStateOf("") }
    var isMorningSession by remember { mutableStateOf(false) }

    val primary = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CarbonSurface)
                .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "REGISTRERA TRÄNINGSPASS",
                style = MaterialTheme.typography.headlineMedium,
                color = primary
            )

            Text("Typ av träning", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TrainingType.entries.forEach { t ->
                    FilterChip(
                        selected = selectedType == t,
                        onClick = {
                            selectedType = t
                            skillFocused = t.swedishName
                        },
                        label = { Text(t.swedishName) }
                    )
                }
            }

            OutlinedTextField(
                value = skillFocused,
                onValueChange = { skillFocused = it },
                label = { Text("Tränad färdighet / teknik") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = durationText,
                onValueChange = { durationText = it.filter { ch -> ch.isDigit() } },
                label = { Text("Varaktighet (minuter)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Intensitet", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TrainingIntensity.entries.forEach { level ->
                    FilterChip(
                        selected = intensity == level,
                        onClick = { intensity = level },
                        label = { Text(level.swedishName) }
                    )
                }
            }

            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Prestationsbetyg", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                    Text(
                        text = String.format("%.1f / 10", rating),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = primary
                    )
                }
                Slider(
                    value = rating,
                    onValueChange = { rating = (it * 10f).roundToInt() / 10f },
                    valueRange = 1.0f..10.0f
                )
            }

            SwitchRowCompact("Morgonpass (före kl 08:00)", isMorningSession) { isMorningSession = it }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Egna anteckningar") },
                placeholder = { Text("Vad gick extra bra idag?") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text("Avbryt")
                }
                Button(
                    onClick = {
                        val mins = durationText.toIntOrNull()?.coerceIn(5, 300) ?: 60
                        val timestamp = if (isMorningSession) {
                            Calendar.getInstance().apply {
                                set(Calendar.HOUR_OF_DAY, 7)
                                set(Calendar.MINUTE, 15)
                            }.timeInMillis
                        } else {
                            System.currentTimeMillis()
                        }
                        onSave(selectedType, skillFocused, mins, intensity, rating, notes, timestamp)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_training_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("SPARA PASS", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun StepperField(label: String, value: Int, onChange: (Int) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(ObsidianBlack)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .clickable { onChange(value - 1) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("-", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            }
            Text(
                text = "$value",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.width(24.dp)
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(ObsidianBlack)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                    .clickable { onChange(value + 1) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("+", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
            }
        }
    }
}

@Composable
private fun SwitchRowCompact(label: String, checked: Boolean, onChanged: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
        Switch(checked = checked, onCheckedChange = onChanged)
    }
}
