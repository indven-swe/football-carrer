package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.PlayerProfileEntity
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.TextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun AttributeRadarChart(
    profile: PlayerProfileEntity,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val stats = listOf(
        "SNB" to profile.pace,
        "SKO" to profile.shooting,
        "PAS" to profile.passing,
        "DRI" to profile.dribbling,
        "FÖR" to profile.defending,
        "FYS" to profile.physical
    )

    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .padding(12.dp)
        ) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = (minOf(size.width, size.height) / 2f) * 0.85f
            val count = stats.size

            // Koncentriska hexagoner
            for (ring in 1..4) {
                val r = radius * (ring / 4f)
                val ringPath = Path()
                for (i in 0 until count) {
                    val angle = -PI / 2 + (2 * PI * i / count)
                    val x = cx + (r * cos(angle)).toFloat()
                    val y = cy + (r * sin(angle)).toFloat()
                    if (i == 0) ringPath.moveTo(x, y) else ringPath.lineTo(x, y)
                }
                ringPath.close()
                drawPath(ringPath, color = BorderSubtle, style = Stroke(width = 1.5f))
            }

            // Axlar
            for (i in 0 until count) {
                val angle = -PI / 2 + (2 * PI * i / count)
                val x = cx + (radius * cos(angle)).toFloat()
                val y = cy + (radius * sin(angle)).toFloat()
                drawLine(color = BorderSubtle, start = Offset(cx, cy), end = Offset(x, y), strokeWidth = 1.5f)
            }

            // Spelarens värdespolygon
            val valuePath = Path()
            val points = mutableListOf<Offset>()
            for (i in 0 until count) {
                val frac = (stats[i].second / 99f).coerceIn(0.15f, 1f)
                val angle = -PI / 2 + (2 * PI * i / count)
                val x = cx + (radius * frac * cos(angle)).toFloat()
                val y = cy + (radius * frac * sin(angle)).toFloat()
                points.add(Offset(x, y))
                if (i == 0) valuePath.moveTo(x, y) else valuePath.lineTo(x, y)
            }
            valuePath.close()
            drawPath(valuePath, color = primary.copy(alpha = 0.25f))
            drawPath(valuePath, color = primary, style = Stroke(width = 3.5f))
            points.forEach { pt ->
                drawCircle(color = primary, radius = 6f, center = pt)
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            stats.forEach { (code, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$value",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = primary
                    )
                    Text(
                        text = code,
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun RatingTrendChart(
    ratings: List<Float>,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    if (ratings.isEmpty()) return

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .padding(horizontal = 8.dp, vertical = 10.dp)
    ) {
        val w = size.width
        val h = size.height

        // Referenslinjer för betyg 5 och 8
        listOf(0.5f, 0.2f).forEach { yRatio ->
            drawLine(
                color = BorderSubtle.copy(alpha = 0.6f),
                start = Offset(0f, h * yRatio),
                end = Offset(w, h * yRatio),
                strokeWidth = 1.5f
            )
        }

        val points = if (ratings.size == 1) {
            val y = h - ((ratings[0] / 10f).coerceIn(0f, 1f) * h)
            listOf(Offset(w * 0.2f, y), Offset(w * 0.8f, y))
        } else {
            val step = w / (ratings.size - 1).coerceAtLeast(1)
            ratings.mapIndexed { index, r ->
                val x = index * step
                val y = h - ((r / 10f).coerceIn(0.05f, 1f) * (h - 16f)) - 8f
                Offset(x, y)
            }
        }

        val linePath = Path()
        val fillPath = Path()
        points.forEachIndexed { i, pt ->
            if (i == 0) {
                linePath.moveTo(pt.x, pt.y)
                fillPath.moveTo(pt.x, h)
                fillPath.lineTo(pt.x, pt.y)
            } else {
                linePath.lineTo(pt.x, pt.y)
                fillPath.lineTo(pt.x, pt.y)
            }
        }
        fillPath.lineTo(points.last().x, h)
        fillPath.close()

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(listOf(primary.copy(alpha = 0.30f), Color.Transparent))
        )
        drawPath(
            path = linePath,
            brush = Brush.horizontalGradient(listOf(primary, secondary)),
            style = Stroke(width = 5f, cap = StrokeCap.Round)
        )
        points.forEach { pt ->
            drawCircle(color = Color(0xFF07090D), radius = 8f, center = pt)
            drawCircle(color = primary, radius = 5f, center = pt)
        }
    }
}

@Composable
fun BarBreakdownChart(
    bars: List<Pair<String, Int>>,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val maxVal = (bars.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)

    Column(modifier = modifier.fillMaxWidth()) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(top = 8.dp)
        ) {
            if (bars.isEmpty()) return@Canvas
            val slotW = size.width / bars.size
            val barW = (slotW * 0.52f).coerceAtMost(48f)
            bars.forEachIndexed { idx, (_, value) ->
                val frac = (value.toFloat() / maxVal).coerceIn(0.04f, 1f)
                val barH = size.height * frac
                val left = idx * slotW + (slotW - barW) / 2f
                val top = size.height - barH
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(primary, primary.copy(alpha = 0.35f))),
                    topLeft = Offset(left, top),
                    size = Size(barW, barH),
                    cornerRadius = CornerRadius(10f, 10f)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            bars.forEach { (label, value) ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$value",
                        style = MaterialTheme.typography.labelSmall,
                        color = primary
                    )
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
