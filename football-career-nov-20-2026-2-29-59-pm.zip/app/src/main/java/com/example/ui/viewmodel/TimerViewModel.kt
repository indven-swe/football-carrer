package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.notifications.NotificationHelper
import com.example.notifications.SoundPlayer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class MatchHalfPhase(val swedishLabel: String) {
    FIRST_HALF("1:a halvlek"),
    HALFTIME("Halvtidspaus"),
    SECOND_HALF("2:a halvlek"),
    FULLTIME("Fulltid")
}

data class TimerUiState(
    // Träningstidtagarur
    val stopwatchMillis: Long = 0L,
    val stopwatchRunning: Boolean = false,
    val stopwatchLaps: List<Long> = emptyList(),

    // Matchtimer med två halvlekar
    val matchHalfMinutes: Int = 45,
    val matchPhase: MatchHalfPhase = MatchHalfPhase.FIRST_HALF,
    val matchElapsedSeconds: Int = 0,
    val matchRunning: Boolean = false,

    // Paustimer
    val pausePresetSeconds: Int = 90,
    val pauseRemainingSeconds: Int = 90,
    val pauseRunning: Boolean = false,

    // Egen anpassningsbar timer
    val customTotalSeconds: Int = 300,
    val customRemainingSeconds: Int = 300,
    val customRunning: Boolean = false
)

class TimerViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(TimerUiState())
    val state: StateFlow<TimerUiState> = _state.asStateFlow()

    private var stopwatchJob: Job? = null
    private var matchJob: Job? = null
    private var pauseJob: Job? = null
    private var customJob: Job? = null

    // --- TRÄNINGSTIDTAGARUR ---
    fun toggleStopwatch() {
        val running = _state.value.stopwatchRunning
        if (running) {
            stopwatchJob?.cancel()
            _state.update { it.copy(stopwatchRunning = false) }
        } else {
            _state.update { it.copy(stopwatchRunning = true) }
            stopwatchJob = viewModelScope.launch {
                var lastTick = System.currentTimeMillis()
                while (true) {
                    delay(100L)
                    val now = System.currentTimeMillis()
                    val delta = now - lastTick
                    lastTick = now
                    _state.update { it.copy(stopwatchMillis = it.stopwatchMillis + delta) }
                }
            }
        }
    }

    fun lapStopwatch() {
        _state.update { it.copy(stopwatchLaps = listOf(it.stopwatchMillis) + it.stopwatchLaps) }
    }

    fun resetStopwatch() {
        stopwatchJob?.cancel()
        _state.update {
            it.copy(stopwatchMillis = 0L, stopwatchRunning = false, stopwatchLaps = emptyList())
        }
    }

    // --- MATCHTIMER MED TVÅ HALVLEKAR ---
    fun setMatchHalfLength(minutes: Int) {
        if (_state.value.matchRunning) return
        _state.update {
            it.copy(
                matchHalfMinutes = minutes.coerceIn(5, 60),
                matchPhase = MatchHalfPhase.FIRST_HALF,
                matchElapsedSeconds = 0
            )
        }
    }

    fun toggleMatchTimer() {
        val current = _state.value
        if (current.matchPhase == MatchHalfPhase.FULLTIME) return
        if (current.matchRunning) {
            matchJob?.cancel()
            _state.update { it.copy(matchRunning = false) }
        } else {
            _state.update { it.copy(matchRunning = true) }
            matchJob = viewModelScope.launch {
                while (true) {
                    delay(1000L)
                    var phaseCompletedTitle: String? = null
                    _state.update { st ->
                        val nextSec = st.matchElapsedSeconds + 1
                        val targetHalfSec = st.matchHalfMinutes * 60
                        when (st.matchPhase) {
                            MatchHalfPhase.FIRST_HALF -> {
                                if (nextSec >= targetHalfSec) {
                                    phaseCompletedTitle = "Halvtid! 1:a halvlek avslutad."
                                    st.copy(
                                        matchElapsedSeconds = 0,
                                        matchPhase = MatchHalfPhase.HALFTIME,
                                        matchRunning = false
                                    )
                                } else {
                                    st.copy(matchElapsedSeconds = nextSec)
                                }
                            }
                            MatchHalfPhase.HALFTIME -> {
                                if (nextSec >= 15 * 60) {
                                    phaseCompletedTitle = "Halvtidspaus klar – dags för 2:a halvlek!"
                                    st.copy(
                                        matchElapsedSeconds = targetHalfSec,
                                        matchPhase = MatchHalfPhase.SECOND_HALF,
                                        matchRunning = false
                                    )
                                } else {
                                    st.copy(matchElapsedSeconds = nextSec)
                                }
                            }
                            MatchHalfPhase.SECOND_HALF -> {
                                if (nextSec >= targetHalfSec * 2) {
                                    phaseCompletedTitle = "Matchen är slut! Fulltid."
                                    st.copy(
                                        matchElapsedSeconds = targetHalfSec * 2,
                                        matchPhase = MatchHalfPhase.FULLTIME,
                                        matchRunning = false
                                    )
                                } else {
                                    st.copy(matchElapsedSeconds = nextSec)
                                }
                            }
                            MatchHalfPhase.FULLTIME -> st.copy(matchRunning = false)
                        }
                    }
                    if (phaseCompletedTitle != null) {
                        notifyTimerDone("Matchtimer", phaseCompletedTitle!!)
                        matchJob?.cancel()
                        break
                    }
                }
            }
        }
    }

    fun advanceMatchPhase() {
        matchJob?.cancel()
        _state.update { st ->
            val halfSec = st.matchHalfMinutes * 60
            when (st.matchPhase) {
                MatchHalfPhase.FIRST_HALF -> st.copy(
                    matchPhase = MatchHalfPhase.HALFTIME,
                    matchElapsedSeconds = 0,
                    matchRunning = false
                )
                MatchHalfPhase.HALFTIME -> st.copy(
                    matchPhase = MatchHalfPhase.SECOND_HALF,
                    matchElapsedSeconds = halfSec,
                    matchRunning = false
                )
                MatchHalfPhase.SECOND_HALF -> st.copy(
                    matchPhase = MatchHalfPhase.FULLTIME,
                    matchElapsedSeconds = halfSec * 2,
                    matchRunning = false
                )
                MatchHalfPhase.FULLTIME -> st
            }
        }
    }

    fun resetMatchTimer() {
        matchJob?.cancel()
        _state.update {
            it.copy(
                matchPhase = MatchHalfPhase.FIRST_HALF,
                matchElapsedSeconds = 0,
                matchRunning = false
            )
        }
    }

    // --- PAUSTIMER ---
    fun setPausePreset(seconds: Int) {
        pauseJob?.cancel()
        _state.update {
            it.copy(
                pausePresetSeconds = seconds,
                pauseRemainingSeconds = seconds,
                pauseRunning = false
            )
        }
    }

    fun togglePauseTimer() {
        if (_state.value.pauseRunning) {
            pauseJob?.cancel()
            _state.update { it.copy(pauseRunning = false) }
        } else {
            if (_state.value.pauseRemainingSeconds <= 0) {
                _state.update { it.copy(pauseRemainingSeconds = it.pausePresetSeconds) }
            }
            _state.update { it.copy(pauseRunning = true) }
            pauseJob = viewModelScope.launch {
                while (true) {
                    delay(1000L)
                    var finished = false
                    _state.update { st ->
                        val next = (st.pauseRemainingSeconds - 1).coerceAtLeast(0)
                        if (next == 0) finished = true
                        st.copy(pauseRemainingSeconds = next, pauseRunning = !finished)
                    }
                    if (finished) {
                        notifyTimerDone("Paustimer klar!", "Pausen är över – kör nästa set!")
                        break
                    }
                }
            }
        }
    }

    fun resetPauseTimer() {
        pauseJob?.cancel()
        _state.update { it.copy(pauseRemainingSeconds = it.pausePresetSeconds, pauseRunning = false) }
    }

    // --- EGEN ANPASSNINGSBAR TIMER ---
    fun setCustomDuration(minutes: Int, seconds: Int) {
        customJob?.cancel()
        val total = (minutes.coerceAtLeast(0) * 60 + seconds.coerceIn(0, 59)).coerceAtLeast(5)
        _state.update {
            it.copy(customTotalSeconds = total, customRemainingSeconds = total, customRunning = false)
        }
    }

    fun toggleCustomTimer() {
        if (_state.value.customRunning) {
            customJob?.cancel()
            _state.update { it.copy(customRunning = false) }
        } else {
            if (_state.value.customRemainingSeconds <= 0) {
                _state.update { it.copy(customRemainingSeconds = it.customTotalSeconds) }
            }
            _state.update { it.copy(customRunning = true) }
            customJob = viewModelScope.launch {
                while (true) {
                    delay(1000L)
                    var finished = false
                    _state.update { st ->
                        val next = (st.customRemainingSeconds - 1).coerceAtLeast(0)
                        if (next == 0) finished = true
                        st.copy(customRemainingSeconds = next, customRunning = !finished)
                    }
                    if (finished) {
                        notifyTimerDone("Egen timer klar!", "Din nedräkning är slutförd.")
                        break
                    }
                }
            }
        }
    }

    fun resetCustomTimer() {
        customJob?.cancel()
        _state.update { it.copy(customRemainingSeconds = it.customTotalSeconds, customRunning = false) }
    }

    private fun notifyTimerDone(title: String, msg: String) {
        val context = getApplication<Application>()
        SoundPlayer.playPreview(context, "urgent_horn")
        SoundPlayer.vibratePulse(context)
        NotificationHelper.showTimerComplete(context, title, msg)
    }
}
