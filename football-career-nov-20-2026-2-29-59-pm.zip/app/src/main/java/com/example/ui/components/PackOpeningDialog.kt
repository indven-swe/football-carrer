package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.local.SeasonSummaryEntity
import com.example.domain.PackRewardResult
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PackOpeningDialog(
    unopenedCount: Int,
    revealedReward: PackRewardResult?,
    onOpenPack: () -> Unit,
    onDismiss: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "packPulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "packScale"
    )
    val primary = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(26.dp))
                .background(
                    Brush.verticalGradient(listOf(SlateCard, CarbonSurface, ObsidianBlack))
                )
                .border(1.5.dp, primary.copy(alpha = 0.7f), RoundedCornerShape(26.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (revealedReward == null) {
                Text(
                    text = "BELÖNINGSPAKET",
                    style = MaterialTheme.typography.headlineMedium,
                    color = primary
                )
                Text(
                    text = "$unopenedCount paket redo att öppnas",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(16.dp))

                Image(
                    painter = painterResource(id = R.drawable.img_pack_gold),
                    contentDescription = "Belöningspaket",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(width = 160.dp, height = 210.dp)
                        .scale(pulseScale)
                        .clip(RoundedCornerShape(18.dp))
                        .border(2.dp, primary, RoundedCornerShape(18.dp))
                )

                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = onOpenPack,
                    enabled = unopenedCount > 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_pack_confirm_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("ÖPPNA PAKET NU", style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Stäng")
                }
            } else {
                val rColor = rarityColor(revealedReward.rarity)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(99.dp))
                        .background(rColor.copy(alpha = 0.2f))
                        .border(1.dp, rColor, RoundedCornerShape(99.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "${revealedReward.rarity.swedishName.uppercase()} BELÖNING",
                        style = MaterialTheme.typography.labelLarge,
                        color = rColor
                    )
                }
                Spacer(Modifier.height(14.dp))
                Icon(
                    imageVector = Icons.Filled.AutoAwesome,
                    contentDescription = null,
                    tint = rColor,
                    modifier = Modifier.size(56.dp)
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = revealedReward.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = revealedReward.subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(14.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(ObsidianBlack.copy(alpha = 0.7f))
                        .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = revealedReward.attributeBoostLabel,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = primary
                    )
                    Text(
                        text = "+${revealedReward.xpBonus} Karriär-XP",
                        style = MaterialTheme.typography.labelLarge,
                        color = rColor
                    )
                }
                Spacer(Modifier.height(18.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pack_reward_done_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("INKASSERA BELÖNING", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
fun SeasonSummaryDialog(
    summary: SeasonSummaryEntity,
    onDismiss: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val ovrDiff = summary.endOvr - summary.startOvr
    val ovrText = if (ovrDiff >= 0) "+$ovrDiff" else "$ovrDiff"

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.verticalGradient(listOf(SlateCard, ObsidianBlack)))
                .border(1.5.dp, primary, RoundedCornerShape(24.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.EmojiEvents,
                contentDescription = null,
                tint = primary,
                modifier = Modifier.size(44.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "SÄSONG ${summary.seasonNumber} SAMMANFATTNING",
                style = MaterialTheme.typography.headlineMedium,
                color = primary,
                textAlign = TextAlign.Center
            )
            Text(
                text = summary.clubName,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                SummaryStatBox("Matcher", "${summary.matchesPlayed}")
                SummaryStatBox("Mål", "${summary.goals}")
                SummaryStatBox("Assist", "${summary.assists}")
                SummaryStatBox("Träningar", "${summary.trainingsCompleted}")
            }

            Spacer(Modifier.height(12.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(CarbonSurface)
                    .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SummaryLine("Total XP under säsongen", "${summary.totalXpEarned} XP")
                SummaryLine("Mest spelade position", summary.mostPlayedPosition)
                SummaryLine("Betygsutveckling (OVR)", "${summary.startOvr} → ${summary.endOvr} ($ovrText)")
                SummaryLine("Upplåsta prestationer", "${summary.achievementsUnlockedCount} / 20")
                SummaryLine("Bästa prestation", summary.bestPerformanceText)
            }

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
            ) {
                Text("STARTA NÄSTA SÄSONG", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun SummaryStatBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}

@Composable
private fun SummaryLine(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
            color = TextPrimary,
            textAlign = TextAlign.End,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}
