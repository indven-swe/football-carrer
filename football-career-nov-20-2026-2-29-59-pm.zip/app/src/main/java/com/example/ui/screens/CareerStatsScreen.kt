package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.MatchRecordEntity
import com.example.data.local.TrainingRecordEntity
import com.example.domain.TrainingIntensity
import com.example.domain.TrainingType
import com.example.ui.components.AttributeRadarChart
import com.example.ui.components.BarBreakdownChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.RatingTrendChart
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.components.SwedishFormatters
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState
import com.example.ui.viewmodel.TimerUiState
import com.example.ui.viewmodel.TimerViewModel
import java.util.Calendar

enum class StatsSubTab(val title: String) {
    MATCHER("Matcher"),
    TRÄNING("Träning"),
    TIMER("Timer"),
    UTVECKLING("Utveckling")
}

@Composable
fun CareerStatsScreen(
    uiState: CareerUiState,
    timerState: TimerUiState,
    timerViewModel: TimerViewModel,
    selectedSubTab: StatsSubTab,
    onSelectSubTab: (StatsSubTab) -> Unit,
    onOpenLogMatch: () -> Unit,
    onOpenLogTraining: (Int) -> Unit,
    onDeleteMatch: (Long) -> Unit,
    onDeleteTraining: (Long) -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp)) {
            SectionHeader(
                title = "Karriär & Statistik",
                subtitle = "Matchhistorik, träning, timer och färdighetsutveckling"
            )
        }
        Spacer(Modifier.height(10.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedSubTab.ordinal,
            containerColor = ObsidianBlack,
            contentColor = primary,
            edgePadding = 16.dp
        ) {
            StatsSubTab.entries.forEach { tab ->
                Tab(
                    selected = selectedSubTab == tab,
                    onClick = { onSelectSubTab(tab) },
                    text = {
                        Text(
                            text = tab.title.uppercase(),
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (selectedSubTab) {
                StatsSubTab.MATCHER -> {
                    item {
                        Button(
                            onClick = onOpenLogMatch,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("stats_log_match_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("REGISTRERA NY MATCH", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    item {
                        val totalMatches = uiState.matches.size
                        val totalGoals = uiState.matches.sumOf { it.goals }
                        val totalAssists = uiState.matches.sumOf { it.assists }
                        val avgRating = if (totalMatches > 0) {
                            uiState.matches.map { it.performanceRating }.average()
                        } else 0.0

                        StadiumCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatMiniColumn("Matcher", "$totalMatches", primary)
                                StatMiniColumn("Mål", "$totalGoals", ChampionGold)
                                StatMiniColumn("Assist", "$totalAssists", MaterialTheme.colorScheme.secondary)
                                StatMiniColumn("Snittbetyg", if (totalMatches > 0) String.format("%.1f", avgRating) else "–", TextPrimary)
                            }
                        }
                    }

                    if (uiState.matches.isNotEmpty()) {
                        item {
                            StadiumCard {
                                Text(
                                    text = "BETYGSUTVECKLING PER MATCH",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = primary
                                )
                                RatingTrendChart(
                                    ratings = uiState.matches.take(10).reversed().map { it.performanceRating }
                                )
                            }
                        }
                    }

                    item {
                        SectionHeader(title = "Matchhistorik", subtitle = "${uiState.matches.size} spelade matcher")
                    }

                    if (uiState.matches.isEmpty()) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Filled.SportsSoccer,
                                title = "Inga matcher registrerade ännu",
                                description = "Logga din första match för att samla XP, låsa upp prestationer och se din formkurva!"
                            )
                        }
                    } else {
                        items(uiState.matches, key = { it.id }) { match ->
                            MatchHistoryCard(match = match, onDelete = { onDeleteMatch(match.id) })
                        }
                    }
                }

                StatsSubTab.TRÄNING -> {
                    item {
                        Button(
                            onClick = { onOpenLogTraining(60) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("stats_log_training_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("REGISTRERA TRÄNINGSPASS", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    item {
                        val now = System.currentTimeMillis()
                        val weekAgo = now - 7L * 24 * 3600 * 1000
                        val monthAgo = now - 30L * 24 * 3600 * 1000
                        val weekTrainings = uiState.trainings.filter { it.dateEpochMillis >= weekAgo }
                        val monthTrainings = uiState.trainings.filter { it.dateEpochMillis >= monthAgo }

                        StadiumCard {
                            Text("TRÄNINGSSTATISTIK", style = MaterialTheme.typography.labelLarge, color = primary)
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatMiniColumn("Veckans pass", "${weekTrainings.size}", primary)
                                StatMiniColumn("Veckans min", "${weekTrainings.sumOf { it.durationMinutes }}m", TextPrimary)
                                StatMiniColumn("Månadens pass", "${monthTrainings.size}", ChampionGold)
                                StatMiniColumn("Månadens min", "${monthTrainings.sumOf { it.durationMinutes }}m", MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }

                    if (uiState.trainings.isNotEmpty()) {
                        item {
                            val grouped = uiState.trainings
                                .groupBy { TrainingType.fromName(it.type).swedishName.substringBefore(" ") }
                                .map { (k, v) -> k to v.sumOf { it.durationMinutes } }
                                .take(5)
                            StadiumCard {
                                Text(
                                    text = "TRÄNINGSMINUTER PER KATEGORI",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = primary
                                )
                                BarBreakdownChart(bars = grouped)
                            }
                        }
                    }

                    item {
                        SectionHeader(title = "Träningslogg", subtitle = "${uiState.trainings.size} genomförda pass")
                    }

                    if (uiState.trainings.isEmpty()) {
                        item {
                            EmptyStateCard(
                                icon = Icons.Filled.FitnessCenter,
                                title = "Inga träningspass loggade ännu",
                                description = "Registrera ditt första träningspass för att utveckla dina färdigheter och tjäna XP!"
                            )
                        }
                    } else {
                        items(uiState.trainings, key = { it.id }) { training ->
                            TrainingHistoryCard(training = training, onDelete = { onDeleteTraining(training.id) })
                        }
                    }
                }

                StatsSubTab.TIMER -> {
                    item {
                        TimerSection(
                            careerState = uiState,
                            timerState = timerState,
                            timerViewModel = timerViewModel,
                            onSaveStopwatchAsTraining = onOpenLogTraining
                        )
                    }
                }

                StatsSubTab.UTVECKLING -> {
                    val profile = uiState.profile
                    if (profile != null) {
                        item {
                            StadiumCard(borderColor = primary.copy(alpha = 0.5f)) {
                                Text("FÄRDIGHETSRADAR", style = MaterialTheme.typography.labelLarge, color = primary)
                                Text(
                                    text = "Dina attribut utvecklas automatiskt när du tränar och spelar matcher.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                Spacer(Modifier.height(8.dp))
                                AttributeRadarChart(profile = profile)
                            }
                        }
                    }

                    item {
                        val cal = Calendar.getInstance()
                        val monthLabel = "Månadsaktivitet"
                        val totalXpFromLogs = uiState.matches.sumOf { it.xpEarned } + uiState.trainings.sumOf { it.xpEarned }
                        StadiumCard {
                            Text(monthLabel.uppercase(), style = MaterialTheme.typography.labelLarge, color = primary)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Intjänad XP från matcher & träning: $totalXpFromLogs XP",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = "Totala mål + assist: ${uiState.matches.sumOf { it.goals + it.assists }} poäng",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Text(
                                text = "Nuvarande år: ${cal.get(Calendar.YEAR)} • Säsong ${uiState.profile?.currentSeasonNumber ?: 1}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMiniColumn(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.headlineMedium, color = color)
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
private fun MatchHistoryCard(match: MatchRecordEntity, onDelete: () -> Unit) {
    val resultLabel = when {
        match.goalsFor > match.goalsAgainst -> "SEGER" to StatusSuccess
        match.goalsFor == match.goalsAgainst -> "OAVGJORT" to ChampionGold
        else -> "FÖRLUST" to StatusError
    }

    StadiumCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(resultLabel.second.copy(alpha = 0.16f))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${resultLabel.first} ${match.goalsFor}-${match.goalsAgainst}",
                            style = MaterialTheme.typography.labelSmall,
                            color = resultLabel.second
                        )
                    }
                    if (match.isManOfTheMatch) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, contentDescription = "Matchens spelare", tint = ChampionGold, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("MOTM", style = MaterialTheme.typography.labelSmall, color = ChampionGold)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${if (match.isAway) "Borta" else "Hemma"} mot ${match.opponent}",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "${SwedishFormatters.formatDate(match.dateEpochMillis)} • Pos: ${match.position} • ${match.minutesPlayed} min",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "${match.goals} mål • ${match.assists} assist • +${match.xpEarned} XP",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                if (match.notes.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(text = match.notes, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianBlack)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = String.format("%.1f", match.performanceRating),
                        style = MaterialTheme.typography.titleLarge,
                        color = ChampionGold
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Ta bort match", tint = TextMuted)
                }
            }
        }
    }
}

@Composable
private fun TrainingHistoryCard(training: TrainingRecordEntity, onDelete: () -> Unit) {
    val type = TrainingType.fromName(training.type)
    val intensity = TrainingIntensity.fromName(training.intensity)

    StadiumCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = type.swedishName,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Text(
                    text = "Fokus: ${training.skillFocused} • Intensitet: ${intensity.swedishName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Text(
                    text = "${SwedishFormatters.formatDate(training.dateEpochMillis)} • ${training.durationMinutes} min • +${training.xpEarned} XP",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                if (training.notes.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(text = training.notes, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format("%.1f", training.performanceRating),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Ta bort träning", tint = TextMuted)
                }
            }
        }
    }
}
