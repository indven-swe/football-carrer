package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.PlayerProfileEntity
import com.example.domain.CardBackgroundStyle
import com.example.domain.CardBorderStyle
import com.example.domain.CardColorPalette
import com.example.domain.CardDesignStyle
import com.example.domain.CardRarityTier
import com.example.domain.PreferredFoot
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RarityBronze
import com.example.ui.theme.RarityGold
import com.example.ui.theme.RarityLegendary
import com.example.ui.theme.RarityPlatinum
import com.example.ui.theme.RaritySilver
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PlayerCardView(
    profile: PlayerProfileEntity,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val design = CardDesignStyle.fromName(profile.cardDesign)
    val bgStyle = CardBackgroundStyle.fromName(profile.cardBackground)
    val borderStyle = CardBorderStyle.fromName(profile.cardBorder)
    val palette = CardColorPalette.fromName(profile.cardColorTheme)
    val rarity = CardRarityTier.fromName(profile.cardRarity)

    val accentColor by animateColorAsState(
        targetValue = when (palette) {
            CardColorPalette.NEONGRÖN -> NeonGreen
            CardColorPalette.MÄSTARGULD -> ChampionGold
            CardColorPalette.CYBERBLÅ -> CyberBlue
            CardColorPalette.PLATINA_VIT -> Color(0xFFE2E8F0)
            CardColorPalette.LEGENDARISK_LILA -> RarityLegendary
        },
        animationSpec = tween(400),
        label = "cardAccent"
    )

    val rarityColor = when (rarity) {
        CardRarityTier.BRONS -> RarityBronze
        CardRarityTier.SILVER -> RaritySilver
        CardRarityTier.GULD -> RarityGold
        CardRarityTier.PLATINA -> RarityPlatinum
        CardRarityTier.LEGENDARISK -> RarityLegendary
    }

    val cardShape = when (design) {
        CardDesignStyle.FUTURISTISK -> GenericShape { size, _ ->
            val w = size.width
            val h = size.height
            val cut = w * 0.08f
            moveTo(cut, 0f)
            lineTo(w - cut, 0f)
            lineTo(w, cut)
            lineTo(w, h * 0.86f)
            lineTo(w * 0.5f, h)
            lineTo(0f, h * 0.86f)
            lineTo(0f, cut)
            close()
        }
        CardDesignStyle.HEXAGON -> GenericShape { size, _ ->
            val w = size.width
            val h = size.height
            moveTo(w * 0.1f, 0f)
            lineTo(w * 0.9f, 0f)
            lineTo(w, h * 0.12f)
            lineTo(w, h * 0.88f)
            lineTo(w * 0.9f, h)
            lineTo(w * 0.1f, h)
            lineTo(0f, h * 0.88f)
            lineTo(0f, h * 0.12f)
            close()
        }
        CardDesignStyle.IKON -> RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp, bottomStart = 40.dp, bottomEnd = 40.dp)
        CardDesignStyle.KLASSISK -> RoundedCornerShape(22.dp)
    }

    val backgroundBrush = when (bgStyle) {
        CardBackgroundStyle.KOLFIBER -> Brush.linearGradient(
            colors = listOf(Color(0xFF0C1017), Color(0xFF192231), Color(0xFF090C11))
        )
        CardBackgroundStyle.NEON_STADION -> Brush.radialGradient(
            colors = listOf(accentColor.copy(alpha = 0.25f), Color(0xFF0E1520), Color(0xFF070A0F))
        )
        CardBackgroundStyle.GULDMETALL -> Brush.linearGradient(
            colors = listOf(Color(0xFF2B2108), Color(0xFF1A160B), Color(0xFF3A2D0C))
        )
        CardBackgroundStyle.GALAX -> Brush.linearGradient(
            colors = listOf(Color(0xFF120C24), Color(0xFF1A1135), Color(0xFF080A12))
        )
    }

    val borderBrush = when (borderStyle) {
        CardBorderStyle.NEON_GLÖD -> Brush.linearGradient(listOf(accentColor, rarityColor, accentColor))
        CardBorderStyle.DUBBEL_METALL -> Brush.linearGradient(listOf(Color(0xFFE2E8F0), Color(0xFF64748B), Color(0xFFE2E8F0)))
        CardBorderStyle.PRISMATISK -> Brush.linearGradient(listOf(NeonGreen, CyberBlue, RarityLegendary, ChampionGold))
        CardBorderStyle.MINIMAL -> Brush.linearGradient(listOf(accentColor.copy(alpha = 0.6f), accentColor.copy(alpha = 0.6f)))
    }

    val borderWidth = if (borderStyle == CardBorderStyle.DUBBEL_METALL) 3.dp else 2.dp

    Box(
        modifier = modifier
            .clip(cardShape)
            .background(backgroundBrush)
            .border(width = borderWidth, brush = borderBrush, shape = cardShape)
    ) {
        // Bakgrundsgeometri (stadionlinjer / FUT-skimmer)
        Canvas(modifier = Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            // Subtila diagonala linjer
            for (i in -2..6) {
                drawLine(
                    color = accentColor.copy(alpha = 0.06f),
                    start = Offset(w * 0.2f * i, 0f),
                    end = Offset(w * 0.2f * i + h * 0.45f, h),
                    strokeWidth = 2f
                )
            }
            // Mittcirkel bakom avatar
            drawCircle(
                color = accentColor.copy(alpha = 0.09f),
                radius = w * 0.34f,
                center = Offset(w * 0.58f, h * 0.34f),
                style = Stroke(width = 2f)
            )
        }

        if (compact) {
            CompactPlayerCardContent(
                profile = profile,
                accentColor = accentColor,
                rarity = rarity,
                rarityColor = rarityColor
            )
        } else {
            FullPlayerCardContent(
                profile = profile,
                accentColor = accentColor,
                rarity = rarity,
                rarityColor = rarityColor
            )
        }
    }
}

@Composable
private fun CompactPlayerCardContent(
    profile: PlayerProfileEntity,
    accentColor: Color,
    rarity: CardRarityTier,
    rarityColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(68.dp)
        ) {
            Text(
                text = "${profile.ovrRating}",
                style = MaterialTheme.typography.displayMedium.copy(fontSize = 38.sp),
                color = accentColor
            )
            Text(
                text = profile.position,
                style = MaterialTheme.typography.labelLarge,
                color = TextPrimary
            )
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(rarityColor.copy(alpha = 0.2f))
                    .border(1.dp, rarityColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = rarity.swedishName.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = rarityColor
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        PlayerAvatar(
            photoUri = profile.photoUri,
            accentColor = accentColor,
            modifier = Modifier.size(72.dp)
        )

        Spacer(Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = profile.name.uppercase(),
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "${profile.club} • #${profile.jerseyNumber}",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MiniStatChip("SNB", profile.pace, accentColor)
                MiniStatChip("SKO", profile.shooting, accentColor)
                MiniStatChip("PAS", profile.passing, accentColor)
                MiniStatChip("DRI", profile.dribbling, accentColor)
            }
        }
    }
}

@Composable
private fun FullPlayerCardContent(
    profile: PlayerProfileEntity,
    accentColor: Color,
    rarity: CardRarityTier,
    rarityColor: Color
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 22.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(78.dp)
            ) {
                Text(
                    text = "${profile.ovrRating}",
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 48.sp),
                    color = accentColor
                )
                Text(
                    text = profile.position,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "#${profile.jerseyNumber}",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                }
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(rarityColor.copy(alpha = 0.18f))
                        .border(1.dp, rarityColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = rarity.swedishName.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = rarityColor
                    )
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                PlayerAvatar(
                    photoUri = profile.photoUri,
                    accentColor = accentColor,
                    modifier = Modifier.size(124.dp)
                )
            }
        }

        Spacer(Modifier.height(14.dp))

        Text(
            text = profile.name.uppercase(),
            style = MaterialTheme.typography.headlineMedium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "${profile.club} • ${profile.nationality} • ${profile.age} år • ${PreferredFoot.fromName(profile.preferredFoot).swedishLabel} fot",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(Modifier.height(12.dp))
        HorizontalDivider(color = accentColor.copy(alpha = 0.3f), thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FullStatRow("SNB", "Snabbhet", profile.pace, accentColor)
                FullStatRow("SKO", "Skott", profile.shooting, accentColor)
                FullStatRow("PAS", "Passningar", profile.passing, accentColor)
            }
            Box(
                modifier = Modifier
                    .width(1.dp)
                    .height(64.dp)
                    .background(accentColor.copy(alpha = 0.22f))
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                FullStatRow("DRI", "Dribbling", profile.dribbling, accentColor)
                FullStatRow("FÖR", "Försvar", profile.defending, accentColor)
                FullStatRow("FYS", "Fysik", profile.physical, accentColor)
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
fun PlayerAvatar(
    photoUri: String?,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(ObsidianBlack.copy(alpha = 0.85f))
            .border(2.dp, accentColor.copy(alpha = 0.8f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (!photoUri.isNullOrBlank()) {
            AsyncImage(
                model = Uri.parse(photoUri),
                contentDescription = "Spelarens profilbild",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Futuristisk europeisk fotbollsspelare-siluett i vektorform
            Canvas(modifier = Modifier.fillMaxSize().padding(12.dp)) {
                val w = size.width
                val h = size.height
                // Huvud
                drawCircle(
                    color = accentColor.copy(alpha = 0.9f),
                    radius = w * 0.18f,
                    center = Offset(w * 0.5f, h * 0.3f)
                )
                // Axlar & matchtröja
                val jerseyPath = Path().apply {
                    moveTo(w * 0.16f, h * 0.95f)
                    lineTo(w * 0.22f, h * 0.58f)
                    lineTo(w * 0.37f, h * 0.50f)
                    lineTo(w * 0.50f, h * 0.57f)
                    lineTo(w * 0.63f, h * 0.50f)
                    lineTo(w * 0.78f, h * 0.58f)
                    lineTo(w * 0.84f, h * 0.95f)
                    close()
                }
                drawPath(
                    path = jerseyPath,
                    brush = Brush.verticalGradient(
                        listOf(accentColor.copy(alpha = 0.85f), accentColor.copy(alpha = 0.25f))
                    )
                )
                drawPath(
                    path = jerseyPath,
                    color = accentColor,
                    style = Stroke(width = 2.5f)
                )
            }
        }
    }
}

@Composable
private fun MiniStatChip(code: String, value: Int, accentColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = "$value",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = accentColor
        )
        Text(
            text = code,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

@Composable
private fun FullStatRow(code: String, label: String, value: Int, accentColor: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$value",
            style = MaterialTheme.typography.titleLarge,
            color = accentColor,
            modifier = Modifier.width(28.dp)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            text = "$code • $label",
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary
        )
    }
}
