package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Basfärger för mörk stadium-design
val ObsidianBlack = Color(0xFF07090D)
val CarbonSurface = Color(0xFF10141C)
val SlateCard = Color(0xFF171D28)
val ElevatedSlate = Color(0xFF202837)
val BorderSubtle = Color(0xFF2A3446)

val TextPrimary = Color(0xFFF3F6FA)
val TextSecondary = Color(0xFF9BA8BE)
val TextMuted = Color(0xFF64728A)

// Primära tema-accenter
val NeonGreen = Color(0xFF00FF66)
val NeonGreenDark = Color(0xFF00B848)
val NeonGreenContainer = Color(0xFF0A2E1A)

val ChampionGold = Color(0xFFFFD13B)
val ChampionGoldContainer = Color(0xFF332807)

val CyberBlue = Color(0xFF00E5FF)
val CyberBlueContainer = Color(0xFF082B36)

val CrimsonFlame = Color(0xFFFF3D5A)
val CrimsonContainer = Color(0xFF360B15)

// Sällsynthetsfärger för prestationer och spelarkort
val RarityBronze = Color(0xFFCD7F32)
val RaritySilver = Color(0xFFC8D6E5)
val RarityGold = Color(0xFFFFD700)
val RarityPlatinum = Color(0xFF00E5FF)
val RarityLegendary = Color(0xFFC084FC)

val StatusSuccess = Color(0xFF00FF66)
val StatusWarning = Color(0xFFFFB020)
val StatusError = Color(0xFFFF4D6A)

enum class AppAccentTheme(
    val id: String,
    val swedishName: String,
    val primary: Color,
    val secondary: Color,
    val container: Color
) {
    NEON_GREEN("neon_green", "Neongrön (Standard)", NeonGreen, CyberBlue, NeonGreenContainer),
    CHAMPION_GOLD("champion_gold", "Guld & Mästare", ChampionGold, NeonGreen, ChampionGoldContainer),
    CYBER_BLUE("cyber_blue", "Cyberblå Arena", CyberBlue, NeonGreen, CyberBlueContainer),
    CRIMSON_FLAME("crimson_flame", "Flammande Röd", CrimsonFlame, ChampionGold, CrimsonContainer);

    companion object {
        fun fromId(id: String): AppAccentTheme = entries.find { it.id == id } ?: NEON_GREEN
    }
}
