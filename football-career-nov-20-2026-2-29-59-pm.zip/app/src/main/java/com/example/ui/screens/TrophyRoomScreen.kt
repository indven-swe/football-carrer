package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.AchievementEntity
import com.example.domain.AchievementRarity
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.RarityPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.components.SwedishFormatters
import com.example.ui.components.rarityColor
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState

@Composable
fun TrophyRoomScreen(
    uiState: CareerUiState,
    onOpenPackDialog: () -> Unit,
    onFinishSeason: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    var filterMode by remember { mutableIntStateOf(0) } // 0=Alla, 1=Upplåsta, 2=Låsta

    val unlockedCount = uiState.achievements.count { it.isUnlocked }
    val filteredAchievements = remember(uiState.achievements, filterMode) {
        when (filterMode) {
            1 -> uiState.achievements.filter { it.isUnlocked }
            2 -> uiState.achievements.filter { !it.isUnlocked }
            else -> uiState.achievements
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Trofévalv-banner
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_trophy_banner),
                    contentDescription = "Troférum",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(155.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(155.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(ObsidianBlack.copy(alpha = 0.25f), ObsidianBlack)
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text("TROFÉRUM", style = MaterialTheme.typography.headlineLarge, color = primary)
                    Text(
                        text = "$unlockedCount / ${uiState.achievements.size} prestationer upplåsta • ${uiState.trophies.size} troféer",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary
                    )
                }
            }
        }

        // Belöningspaket & Säsongsavslut
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onOpenPackDialog,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("trophy_open_pack_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ChampionGold, contentColor = ObsidianBlack)
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Paket (${uiState.unopenedPacks})", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = onFinishSeason,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("finish_season_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.WorkspacePremium, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Avsluta säsong", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // Personliga rekord
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SectionHeader(title = "Personliga rekord", subtitle = "Dina högsta toppar i karriären")
                uiState.personalRecords.forEach { rec ->
                    StadiumCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = rec.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                Text(text = rec.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                            }
                            Text(
                                text = rec.value,
                                style = MaterialTheme.typography.titleLarge,
                                color = primary
                            )
                        }
                    }
                }
            }
        }

        // Säsongstroféer & Paketbelöningar
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SectionHeader(title = "Säsongstroféer & Samling", subtitle = "Sparade säsongssammanfattningar och milstolpar")
                if (uiState.trophies.isEmpty() && uiState.seasonSummaries.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Filled.MilitaryTech,
                        title = "Inga säsongstroféer ännu",
                        description = "Öppna belöningspaket, gör hattrick eller avsluta din första säsong för att fylla pokalskåpet!"
                    )
                } else {
                    uiState.seasonSummaries.forEach { summary ->
                        StadiumCard(borderColor = ChampionGold.copy(alpha = 0.55f)) {
                            Text(
                                text = "SÄSONG ${summary.seasonNumber} • ${summary.clubName}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = ChampionGold
                            )
                            Text(
                                text = "${summary.matchesPlayed} matcher • ${summary.goals} mål • ${summary.assists} assist • ${summary.trainingsCompleted} träningar",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextPrimary
                            )
                            Text(
                                text = "OVR ${summary.startOvr} → ${summary.endOvr} • Bästa: ${summary.bestPerformanceText}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }
                    uiState.trophies.forEach { trophy ->
                        val rarity = AchievementRarity.fromName(trophy.rarity)
                        StadiumCard(borderColor = rarityColor(rarity).copy(alpha = 0.5f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = trophy.title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
                                    Text(text = trophy.subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                }
                                RarityPill(rarity = rarity, unlocked = true)
                            }
                        }
                    }
                }
            }
        }

        // 20 Prestationer
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionHeader(
                    title = "Prestationer (20)",
                    subtitle = "Låses upp automatiskt när kraven uppfylls"
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = filterMode == 0,
                        onClick = { filterMode = 0 },
                        label = { Text("Alla (${uiState.achievements.size})") }
                    )
                    FilterChip(
                        selected = filterMode == 1,
                        onClick = { filterMode = 1 },
                        label = { Text("Upplåsta ($unlockedCount)") }
                    )
                    FilterChip(
                        selected = filterMode == 2,
                        onClick = { filterMode = 2 },
                        label = { Text("Låsta (${uiState.achievements.size - unlockedCount})") }
                    )
                }
            }
        }

        items(filteredAchievements, key = { it.id }) { ach ->
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                AchievementCard(achievement = ach)
            }
        }
    }
}

@Composable
private fun AchievementCard(achievement: AchievementEntity) {
    val rarity = AchievementRarity.fromName(achievement.rarity)
    val rColor = rarityColor(rarity)
    val primary = MaterialTheme.colorScheme.primary

    val pulseScale = if (achievement.isUnlocked) {
        val transition = rememberInfiniteTransition(label = "achGlow_${achievement.id}")
        val s by transition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse),
            label = "achIconScale"
        )
        s
    } else 1.0f

    val containerModifier = if (achievement.isUnlocked) {
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(SlateCard)
            .border(1.5.dp, rColor.copy(alpha = 0.75f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    } else {
        Modifier
            .fillMaxWidth()
            .alpha(0.62f)
            .clip(RoundedCornerShape(20.dp))
            .background(CarbonSurface)
            .border(1.dp, BorderSubtle, RoundedCornerShape(20.dp))
            .padding(16.dp)
    }

    Column(modifier = containerModifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(if (achievement.isUnlocked) rColor.copy(alpha = 0.18f) else ObsidianBlack)
                    .border(1.5.dp, if (achievement.isUnlocked) rColor else TextMuted, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (achievement.isUnlocked) Icons.Filled.EmojiEvents else Icons.Filled.Lock,
                    contentDescription = if (achievement.isUnlocked) "Upplåst" else "Låst",
                    tint = if (achievement.isUnlocked) rColor else TextMuted,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = achievement.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = if (achievement.isUnlocked) TextPrimary else TextSecondary
                    )
                    RarityPill(rarity = rarity, unlocked = achievement.isUnlocked)
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = achievement.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Krav: ${achievement.requirementText}",
                style = MaterialTheme.typography.bodySmall,
                color = if (achievement.isUnlocked) rColor else TextMuted
            )
            Text(
                text = "+${achievement.xpReward} XP",
                style = MaterialTheme.typography.labelSmall,
                color = if (achievement.isUnlocked) primary else TextMuted
            )
        }

        Spacer(Modifier.height(6.dp))
        LinearProgressIndicator(
            progress = {
                (achievement.progressCurrent.toFloat() / achievement.progressTarget.coerceAtLeast(1)).coerceIn(0f, 1f)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(99.dp)),
            color = if (achievement.isUnlocked) rColor else TextMuted,
            trackColor = ObsidianBlack
        )

        if (achievement.isUnlocked && achievement.unlockedAtMillis != null) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = "Upplåst ${SwedishFormatters.formatDate(achievement.unlockedAtMillis)}",
                style = MaterialTheme.typography.bodySmall,
                color = primary
            )
        }
    }
}
