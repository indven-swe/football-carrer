package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.local.NotificationPreferences
import com.example.domain.NotificationSoundOption
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun NotificationSettingsDialog(
    prefs: NotificationPreferences,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onUpdatePrefs: (NotificationPreferences) -> Unit,
    onPreviewSound: (String) -> Unit,
    onSendTestNotification: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CarbonSurface)
                .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.NotificationsActive, contentDescription = null, tint = primary)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "NOTISER & LJUD",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary
                )
            }
            Text(
                text = "Anpassa påminnelser, aviseringsljud och vibration för matcher & träningar.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            if (!hasPermission) {
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = onRequestPermission,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("TILLÅT NOTISER I ANDROID", style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(Modifier.height(14.dp))
            SettingToggleRow(
                title = "Aktivera påminnelser",
                subtitle = "Schemalägger automatiskt för alla aktiviteter",
                checked = prefs.remindersEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(remindersEnabled = it)) }
            )
            SettingToggleRow(
                title = "Påminnelse 1 timme innan",
                subtitle = "Exempel: MATCH OM 1 TIMME!",
                checked = prefs.notify1hEnabled,
                enabled = prefs.remindersEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(notify1hEnabled = it)) }
            )
            SettingToggleRow(
                title = "Påminnelse 30 minuter innan",
                subtitle = "Exempel: TRÄNING OM 30 MINUTER!",
                checked = prefs.notify30mEnabled,
                enabled = prefs.remindersEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(notify30mEnabled = it)) }
            )
            SettingToggleRow(
                title = "Påminnelse 15 minuter innan",
                subtitle = "15 MINUTER KVAR. DAGS ATT GÖRA SIG REDO!",
                checked = prefs.notify15mEnabled,
                enabled = prefs.remindersEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(notify15mEnabled = it)) }
            )
            SettingToggleRow(
                title = "Notis vid upplåst prestation",
                subtitle = "Få avisering när nya troféer låses upp",
                checked = prefs.achievementNotificationsEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(achievementNotificationsEnabled = it)) }
            )
            SettingToggleRow(
                title = "Vibration",
                subtitle = "Vibrera vid match- och träningsnotiser",
                checked = prefs.vibrationEnabled,
                onCheckedChange = { onUpdatePrefs(prefs.copy(vibrationEnabled = it)) }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = BorderSubtle)

            SoundPickerSection(
                title = "Ljud för Matcher & Turneringar",
                selectedSoundId = prefs.matchSoundId,
                onSelect = { onUpdatePrefs(prefs.copy(matchSoundId = it)) },
                onPreview = onPreviewSound
            )

            Spacer(Modifier.height(12.dp))

            SoundPickerSection(
                title = "Ljud för Träningar & Gympass",
                selectedSoundId = prefs.trainingSoundId,
                onSelect = { onUpdatePrefs(prefs.copy(trainingSoundId = it)) },
                onPreview = onPreviewSound
            )

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onSendTestNotification(true) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("test_match_notif_button")
                ) {
                    Text("Testa matchnotis", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(
                    onClick = { onSendTestNotification(false) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("test_training_notif_button")
                ) {
                    Text("Testa träningsnotis", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = onDismiss,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
            ) {
                Text("SPARA & STÄNG", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, color = TextPrimary)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange
        )
    }
}

@Composable
private fun SoundPickerSection(
    title: String,
    selectedSoundId: String,
    onSelect: (String) -> Unit,
    onPreview: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SlateCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Filled.VolumeUp,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
        }
        Spacer(Modifier.height(6.dp))
        NotificationSoundOption.entries.forEach { option ->
            val selected = option.id == selectedSoundId
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelect(option.id) }
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = selected, onClick = { onSelect(option.id) })
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = option.swedishName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Text(text = option.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                IconButton(onClick = { onPreview(option.id) }) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Spela upp ${option.swedishName}",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}
