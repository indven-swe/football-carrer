package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.domain.AchievementRarity
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.RarityBronze
import com.example.ui.theme.RarityGold
import com.example.ui.theme.RarityLegendary
import com.example.ui.theme.RarityPlatinum
import com.example.ui.theme.RaritySilver
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StadiumCard(
    modifier: Modifier = Modifier,
    borderColor: Color = BorderSubtle,
    containerColor: Color = SlateCard,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title.uppercase(),
                style = MaterialTheme.typography.titleLarge,
                color = TextPrimary
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
        if (trailing != null) {
            trailing()
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    description: String,
    modifier: Modifier = Modifier
) {
    StadiumCard(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(38.dp)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun RarityPill(rarity: AchievementRarity, unlocked: Boolean = true) {
    val color = if (!unlocked) TextMuted else rarityColor(rarity)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = rarity.swedishName.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

fun rarityColor(rarity: AchievementRarity): Color = when (rarity) {
    AchievementRarity.BRONS -> RarityBronze
    AchievementRarity.SILVER -> RaritySilver
    AchievementRarity.GULD -> RarityGold
    AchievementRarity.PLATINA -> RarityPlatinum
    AchievementRarity.LEGENDARISK -> RarityLegendary
}

object SwedishFormatters {
    private val svLocale = Locale("sv", "SE")
    private val dateFormat = SimpleDateFormat("d MMM yyyy", svLocale)
    private val dateTimeFormat = SimpleDateFormat("EEE d MMM • HH:mm", svLocale)
    private val timeOnlyFormat = SimpleDateFormat("HH:mm", svLocale)

    fun formatDate(millis: Long): String = dateFormat.format(Date(millis))
    fun formatDateTime(millis: Long): String = dateTimeFormat.format(Date(millis))
    fun formatTime(millis: Long): String = timeOnlyFormat.format(Date(millis))

    fun formatCountdown(targetMillis: Long, nowMillis: Long): String {
        val diff = (targetMillis - nowMillis).coerceAtLeast(0L)
        val totalSeconds = diff / 1000L
        val days = totalSeconds / 86400L
        val hours = (totalSeconds % 86400L) / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return when {
            days > 0 -> "${days}d ${hours}t ${minutes}m"
            hours > 0 -> String.format(svLocale, "%02d:%02d:%02d", hours, minutes, seconds)
            else -> String.format(svLocale, "%02d:%02d", minutes, seconds)
        }
    }

    fun formatSecondsClock(totalSeconds: Int): String {
        val safe = totalSeconds.coerceAtLeast(0)
        val mins = safe / 60
        val secs = safe % 60
        return String.format(svLocale, "%02d:%02d", mins, secs)
    }

    fun formatStopwatch(millis: Long): String {
        val totalSeconds = millis / 1000L
        val mins = totalSeconds / 60L
        val secs = totalSeconds % 60L
        val tenths = (millis % 1000L) / 100L
        return String.format(svLocale, "%02d:%02d.%d", mins, secs, tenths)
    }
}
