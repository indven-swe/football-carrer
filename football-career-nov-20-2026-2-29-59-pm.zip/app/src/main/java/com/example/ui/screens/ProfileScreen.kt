package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.local.PlayerProfileEntity
import com.example.domain.CardBackgroundStyle
import com.example.domain.CardBorderStyle
import com.example.domain.CardColorPalette
import com.example.domain.CardDesignStyle
import com.example.domain.CardRarityTier
import com.example.domain.PlayerPosition
import com.example.domain.PreferredFoot
import com.example.ui.components.PlayerCardView
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.theme.AppAccentTheme
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState

@Composable
fun ProfileScreen(
    uiState: CareerUiState,
    onSaveProfile: (PlayerProfileEntity) -> Unit,
    onSelectAppTheme: (String) -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    val profile = uiState.profile ?: return
    val context = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary

    var name by remember(profile.id) { mutableStateOf(profile.name) }
    var club by remember(profile.id) { mutableStateOf(profile.club) }
    var nationality by remember(profile.id) { mutableStateOf(profile.nationality) }
    var jerseyText by remember(profile.id) { mutableStateOf(profile.jerseyNumber.toString()) }
    var ageText by remember(profile.id) { mutableStateOf(profile.age.toString()) }
    var position by remember(profile.id) { mutableStateOf(profile.position) }
    var preferredFoot by remember(profile.id) { mutableStateOf(profile.preferredFoot) }
    var photoUri by remember(profile.id) { mutableStateOf(profile.photoUri) }

    var cardDesign by remember(profile.id) { mutableStateOf(profile.cardDesign) }
    var cardBackground by remember(profile.id) { mutableStateOf(profile.cardBackground) }
    var cardBorder by remember(profile.id) { mutableStateOf(profile.cardBorder) }
    var cardColorTheme by remember(profile.id) { mutableStateOf(profile.cardColorTheme) }
    var cardRarity by remember(profile.id) { mutableStateOf(profile.cardRarity) }

    LaunchedEffect(profile.ovrRating, profile.level, profile.totalXp) {
        cardRarity = profile.cardRarity
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Vissa systemväljare ger temporär läsrättighet
            }
            photoUri = uri.toString()
            onSaveProfile(profile.copy(photoUri = uri.toString()))
        }
    }

    val previewProfile = profile.copy(
        name = name.ifBlank { profile.name },
        club = club.ifBlank { profile.club },
        nationality = nationality.ifBlank { profile.nationality },
        jerseyNumber = jerseyText.toIntOrNull()?.coerceIn(1, 99) ?: profile.jerseyNumber,
        age = ageText.toIntOrNull()?.coerceIn(6, 65) ?: profile.age,
        position = position,
        preferredFoot = preferredFoot,
        photoUri = photoUri,
        cardDesign = cardDesign,
        cardBackground = cardBackground,
        cardBorder = cardBorder,
        cardColorTheme = cardColorTheme,
        cardRarity = cardRarity
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Spelarprofil & Kort",
                subtitle = "Anpassa din spelare, spelarkort och tema"
            )
        }

        // Live-förhandsvisning av Spelarkort
        item {
            PlayerCardView(
                profile = previewProfile,
                compact = false,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Profilbild & Snabbknapp för Notiser
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("pick_profile_photo_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Välj profilbild")
                }

                OutlinedButton(
                    onClick = onOpenNotificationSettings,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("profile_notif_settings_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Notiser & ljud")
                }
            }
        }

        // Spelarinformation
        item {
            StadiumCard {
                Text("SPELARINFORMATION", style = MaterialTheme.typography.labelLarge, color = primary)
                Spacer(Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Namn") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_name_input")
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = club,
                    onValueChange = { club = it },
                    label = { Text("Klubb") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = jerseyText,
                        onValueChange = { jerseyText = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Tröjnummer") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = { ageText = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Ålder") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = nationality,
                    onValueChange = { nationality = it },
                    label = { Text("Nationalitet") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(10.dp))
                Text("Position", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PlayerPosition.entries.forEach { pos ->
                        FilterChip(
                            selected = position == pos.code,
                            onClick = { position = pos.code },
                            label = { Text("${pos.code} (${pos.swedishName})") }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Favoritfot", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PreferredFoot.entries.forEach { foot ->
                        FilterChip(
                            selected = preferredFoot == foot.name,
                            onClick = { preferredFoot = foot.name },
                            label = { Text(foot.swedishLabel) }
                        )
                    }
                }
            }
        }

        // Kortanpassning
        item {
            StadiumCard {
                Text("ANPASSA SPELARKORT", style = MaterialTheme.typography.labelLarge, color = primary)
                Spacer(Modifier.height(10.dp))

                Text("Kortdesign", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CardDesignStyle.entries.forEach { item ->
                        FilterChip(
                            selected = cardDesign == item.name,
                            onClick = { cardDesign = item.name },
                            label = { Text(item.swedishName) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Bakgrund", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CardBackgroundStyle.entries.forEach { item ->
                        FilterChip(
                            selected = cardBackground == item.name,
                            onClick = { cardBackground = item.name },
                            label = { Text(item.swedishName) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Kanter", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CardBorderStyle.entries.forEach { item ->
                        FilterChip(
                            selected = cardBorder == item.name,
                            onClick = { cardBorder = item.name },
                            label = { Text(item.swedishName) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Kortfärg", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CardColorPalette.entries.forEach { item ->
                        FilterChip(
                            selected = cardColorTheme == item.name,
                            onClick = { cardColorTheme = item.name },
                            label = { Text(item.swedishName) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Sällsynthetsnivå", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    CardRarityTier.entries.forEach { item ->
                        FilterChip(
                            selected = cardRarity == item.name,
                            onClick = { cardRarity = item.name },
                            label = { Text(item.swedishName) }
                        )
                    }
                }
            }
        }

        // Anpassningsbart App-tema
        item {
            StadiumCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Palette, contentDescription = null, tint = primary)
                    Spacer(Modifier.width(8.dp))
                    Text("ANPASSNINGSBART TEMA", style = MaterialTheme.typography.labelLarge, color = primary)
                }
                Spacer(Modifier.height(10.dp))
                AppAccentTheme.entries.forEach { themeOption ->
                    val selected = profile.appThemeId == themeOption.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) themeOption.primary else BorderSubtle,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectAppTheme(themeOption.id) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(themeOption.primary)
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(text = themeOption.swedishName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                        }
                        if (selected) {
                            Text("AKTIV", style = MaterialTheme.typography.labelSmall, color = themeOption.primary)
                        }
                    }
                }
            }
        }

        // Spara-knapp
        item {
            Button(
                onClick = { onSaveProfile(previewProfile) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("save_profile_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
            ) {
                Icon(Icons.Filled.Save, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("SPARA PROFIL & SPELARKORT", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
