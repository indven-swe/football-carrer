package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.LevelProgress
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun XpProgressBar(
    levelProgress: LevelProgress,
    modifier: Modifier = Modifier
) {
    val animatedFraction by animateFloatAsState(
        targetValue = levelProgress.progressFraction.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = 220f, dampingRatio = 0.78f),
        label = "xpProgress"
    )
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(SlateCard)
            .border(1.dp, BorderSubtle, RoundedCornerShape(18.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(primary.copy(alpha = 0.16f))
                        .border(1.dp, primary, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "NIVÅ ${levelProgress.level}",
                        style = MaterialTheme.typography.labelLarge,
                        color = primary
                    )
                }
                Text(
                    text = "  av 100",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            val xpIntoLevel = (levelProgress.totalXp - levelProgress.currentLevelStartXp).coerceAtLeast(0)
            val xpSpan = (levelProgress.nextLevelXp - levelProgress.currentLevelStartXp).coerceAtLeast(1)
            Text(
                text = if (levelProgress.level >= 100) "${levelProgress.totalXp} XP (MAX)"
                else "$xpIntoLevel / $xpSpan XP",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
        }

        Spacer(Modifier.height(10.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(ObsidianBlack)
                .border(1.dp, ElevatedSlate, RoundedCornerShape(99.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(animatedFraction.coerceAtLeast(0.03f))
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(99.dp))
                    .background(Brush.horizontalGradient(listOf(primary, secondary)))
            )
        }

        Spacer(Modifier.height(6.dp))

        Text(
            text = "Total karriär-XP: ${levelProgress.totalXp} XP",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )
    }
}
