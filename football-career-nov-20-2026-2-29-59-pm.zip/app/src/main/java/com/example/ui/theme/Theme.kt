package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.dp

val LocalAccentTheme = staticCompositionLocalOf { AppAccentTheme.NEON_GREEN }

val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun FootballCareerTheme(
    accentTheme: AppAccentTheme = AppAccentTheme.NEON_GREEN,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = accentTheme.primary,
        onPrimary = ObsidianBlack,
        primaryContainer = accentTheme.container,
        onPrimaryContainer = accentTheme.primary,
        secondary = accentTheme.secondary,
        onSecondary = ObsidianBlack,
        secondaryContainer = ElevatedSlate,
        onSecondaryContainer = TextPrimary,
        tertiary = ChampionGold,
        onTertiary = ObsidianBlack,
        tertiaryContainer = ChampionGoldContainer,
        onTertiaryContainer = ChampionGold,
        background = ObsidianBlack,
        onBackground = TextPrimary,
        surface = CarbonSurface,
        onSurface = TextPrimary,
        surfaceVariant = SlateCard,
        onSurfaceVariant = TextSecondary,
        surfaceContainerLow = CarbonSurface,
        surfaceContainer = SlateCard,
        surfaceContainerHigh = ElevatedSlate,
        outline = BorderSubtle,
        outlineVariant = ColorBorderMuted,
        error = StatusError,
        onError = ObsidianBlack
    )

    CompositionLocalProvider(LocalAccentTheme provides accentTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            shapes = AppShapes,
            content = content
        )
    }
}

private val ColorBorderMuted = androidx.compose.ui.graphics.Color(0xFF1E2533)
