package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.ChallengeEntity
import com.example.domain.AchievementRarity
import com.example.domain.ActivityType
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.PlayerCardView
import com.example.ui.components.RarityPill
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.components.SwedishFormatters
import com.example.ui.components.XpProgressBar
import com.example.ui.components.rarityColor
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState
import java.util.Calendar

@Composable
fun HomeScreen(
    uiState: CareerUiState,
    onOpenLogMatch: () -> Unit,
    onOpenLogTraining: () -> Unit,
    onOpenPackDialog: () -> Unit,
    onOpenNotifications: () -> Unit,
    onNavigateToCalendar: () -> Unit,
    onNavigateToTimer: () -> Unit,
    onNavigateToTrophies: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onCompleteChallenge: (ChallengeEntity) -> Unit,
    onGenerateRandomChallenge: () -> Unit
) {
    val profile = uiState.profile ?: return
    val primary = MaterialTheme.colorScheme.primary

    // Veckostatistik beräkning
    val weekStartMillis = Calendar.getInstance().apply {
        set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    val weekMatches = uiState.matches.filter { it.dateEpochMillis >= weekStartMillis }
    val weekTrainings = uiState.trainings.filter { it.dateEpochMillis >= weekStartMillis }
    val weekMinutes = weekMatches.sumOf { it.minutesPlayed } + weekTrainings.sumOf { it.durationMinutes }

    val unlockedAchievements = uiState.achievements.filter { it.isUnlocked }
        .sortedByDescending { it.unlockedAtMillis ?: 0L }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Stadium Hero Header + Spelarkort
        item {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_stadium_hero),
                    contentDescription = "Fotbollsstadion",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(175.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    ObsidianBlack.copy(alpha = 0.35f),
                                    ObsidianBlack.copy(alpha = 0.78f),
                                    ObsidianBlack
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "FOOTBALL CAREER",
                                style = MaterialTheme.typography.headlineMedium,
                                color = primary
                            )
                            Text(
                                text = "Säsong ${profile.currentSeasonNumber} • ${profile.club}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(SlateCard.copy(alpha = 0.9f))
                                    .border(1.dp, ChampionGold.copy(alpha = 0.6f), RoundedCornerShape(99.dp))
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.LocalFireDepartment,
                                        contentDescription = "Träningssvit",
                                        tint = ChampionGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        text = "${profile.activeStreakDays}d svit",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ChampionGold
                                    )
                                }
                            }

                            IconButton(
                                onClick = onOpenNotifications,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SlateCard.copy(alpha = 0.9f))
                                    .testTag("home_notifications_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = "Notisinställningar",
                                    tint = primary
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    PlayerCardView(
                        profile = profile,
                        compact = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToProfile() }
                            .testTag("home_player_card")
                    )
                }
            }
        }

        // 2. XP-mätare
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                XpProgressBar(levelProgress = uiState.levelProgress)
            }
        }

        // 3. Nästa aktivitet med nedräkning
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                val next = uiState.nextActivity
                StadiumCard(
                    borderColor = if (next != null) primary.copy(alpha = 0.65f) else BorderSubtle
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "NÄSTA AKTIVITET",
                            style = MaterialTheme.typography.labelLarge,
                            color = primary
                        )
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onNavigateToTimer() }
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Timer,
                                contentDescription = null,
                                tint = primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("Öppna timer", style = MaterialTheme.typography.labelMedium, color = primary)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    if (next != null) {
                        val type = ActivityType.fromName(next.type)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = next.title,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${type.swedishLabel} • ${SwedishFormatters.formatDateTime(next.startTimeMillis)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                                if (next.location.isNotBlank()) {
                                    Text(
                                        text = "Plats: ${next.location}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = SwedishFormatters.formatCountdown(next.startTimeMillis, uiState.nowMillis),
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = primary
                                )
                                Text(
                                    text = "kvar",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ingen inplanerad aktivitet",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Lägg till nästa match eller träning i kalendern för live-nedräkning och automatiska påminnelser.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            OutlinedButton(
                                onClick = onNavigateToCalendar,
                                modifier = Modifier.testTag("home_add_calendar_button")
                            ) {
                                Icon(Icons.Filled.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Kalender")
                            }
                        }
                    }
                }
            }
        }

        // 4. Snabbknappar
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SectionHeader(title = "Snabbåtgärder", subtitle = "Logga prestationer och tjäna XP direkt")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpenLogMatch,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("quick_log_match_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                    ) {
                        Icon(Icons.Filled.SportsSoccer, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Registrera match", style = MaterialTheme.typography.labelLarge, maxLines = 1)
                    }

                    Button(
                        onClick = onOpenLogTraining,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("quick_log_training_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElevatedSlate, contentColor = TextPrimary)
                    ) {
                        Icon(Icons.Filled.FitnessCenter, contentDescription = null, tint = primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Registrera träning", style = MaterialTheme.typography.labelLarge, maxLines = 1)
                    }
                }

                if (uiState.unopenedPacks > 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(primary.copy(alpha = 0.22f), ChampionGold.copy(alpha = 0.22f))
                                )
                            )
                            .border(1.dp, ChampionGold, RoundedCornerShape(16.dp))
                            .clickable { onOpenPackDialog() }
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .testTag("home_open_pack_banner")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = ChampionGold)
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "DU HAR ${uiState.unopenedPacks} OÖPPNAT BELÖNINGSPAKET!",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = ChampionGold
                                    )
                                    Text(
                                        text = "Tryck för att öppna och få attributboost + XP",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextPrimary
                                    )
                                }
                            }
                            Text("ÖPPNA", style = MaterialTheme.typography.labelLarge, color = primary)
                        }
                    }
                }
            }
        }

        // 5. Veckostatistik
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(title = "Veckostatistik", subtitle = "Din aktivitet den här veckan")
                StadiumCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        WeekMetric("Träningar", "${weekTrainings.size}", primary)
                        WeekMetric("Matcher", "${weekMatches.size}", primary)
                        WeekMetric("Mål", "${weekMatches.sumOf { it.goals }}", ChampionGold)
                        WeekMetric("Assist", "${weekMatches.sumOf { it.assists }}", MaterialTheme.colorScheme.secondary)
                        WeekMetric("Minuter", "$weekMinutes", TextPrimary)
                    }
                }
            }
        }

        // 6. Dagens utmaning & Slumpade utmaningar
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionHeader(
                    title = "Dagens utmaningar",
                    subtitle = "Slutför för bonus-XP och belöningspaket",
                    trailing = {
                        OutlinedButton(
                            onClick = onGenerateRandomChallenge,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("random_challenge_button")
                        ) {
                            Icon(Icons.Filled.Shuffle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Slumpa", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                )

                val visibleChallenges = uiState.challenges.take(4)
                visibleChallenges.forEach { challenge ->
                    ChallengeCard(
                        challenge = challenge,
                        onComplete = { onCompleteChallenge(challenge) }
                    )
                }
            }
        }

        // 7. Senaste prestationer
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SectionHeader(
                        title = "Senaste prestationer",
                        subtitle = "${unlockedAchievements.size} av ${uiState.achievements.size} upplåsta",
                        trailing = {
                            Text(
                                text = "Visa alla",
                                style = MaterialTheme.typography.labelLarge,
                                color = primary,
                                modifier = Modifier
                                    .clickable { onNavigateToTrophies() }
                                    .padding(6.dp)
                            )
                        }
                    )
                }

                if (unlockedAchievements.isEmpty()) {
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        EmptyStateCard(
                            icon = Icons.Filled.EmojiEvents,
                            title = "Inga upplåsta prestationer ännu",
                            description = "Logga din första träning eller match för att låsa upp \"Första touchen\" och samla troféer!"
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        unlockedAchievements.take(6).forEach { ach ->
                            val rarity = AchievementRarity.fromName(ach.rarity)
                            val rColor = rarityColor(rarity)
                            Column(
                                modifier = Modifier
                                    .width(190.dp)
                                    .clip(RoundedCornerShape(18.dp))
                                    .background(SlateCard)
                                    .border(1.dp, rColor.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
                                    .clickable { onNavigateToTrophies() }
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.EmojiEvents,
                                        contentDescription = null,
                                        tint = rColor,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    RarityPill(rarity = rarity, unlocked = true)
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = ach.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "+${ach.xpReward} XP",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeekMetric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, style = MaterialTheme.typography.headlineMedium, color = color)
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}

@Composable
private fun ChallengeCard(
    challenge: ChallengeEntity,
    onComplete: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    StadiumCard(
        borderColor = if (challenge.isCompleted) primary.copy(alpha = 0.4f) else BorderSubtle,
        containerColor = if (challenge.isCompleted) CarbonSurface else SlateCard
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(
                        imageVector = if (challenge.isCompleted) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
                        contentDescription = null,
                        tint = if (challenge.isCompleted) primary else ChampionGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = challenge.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = TextPrimary
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = challenge.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = {
                        (challenge.currentCount.toFloat() / challenge.targetCount.coerceAtLeast(1)).coerceIn(0f, 1f)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(99.dp)),
                    color = primary,
                    trackColor = ObsidianBlack
                )
            }

            if (challenge.isCompleted) {
                Text(
                    text = "KLAR",
                    style = MaterialTheme.typography.labelLarge,
                    color = primary
                )
            } else {
                Button(
                    onClick = onComplete,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("+${challenge.xpReward} XP", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
