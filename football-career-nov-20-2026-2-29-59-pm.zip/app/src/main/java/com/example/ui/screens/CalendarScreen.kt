package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.local.CalendarActivityEntity
import com.example.domain.ActivityType
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StadiumCard
import com.example.ui.components.SwedishFormatters
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.ChampionGold
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RarityLegendary
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerUiState
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun CalendarScreen(
    uiState: CareerUiState,
    onAddActivity: (CalendarActivityEntity) -> Unit,
    onCompleteActivity: (CalendarActivityEntity) -> Unit,
    onDeleteActivity: (Long) -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    var displayedMonthOffset by remember { mutableIntStateOf(0) }
    var selectedDayKey by remember { mutableStateOf<String?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val monthCal = remember(displayedMonthOffset) {
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            add(Calendar.MONTH, displayedMonthOffset)
        }
    }
    val monthTitle = remember(monthCal.timeInMillis) {
        SimpleDateFormat("MMMM yyyy", Locale("sv", "SE"))
            .format(Date(monthCal.timeInMillis))
            .replaceFirstChar { it.uppercase() }
    }

    val activitiesByDay = remember(uiState.activities) {
        uiState.activities.groupBy { dayKeyForMillis(it.startTimeMillis) }
    }
    val todayKey = remember(uiState.nowMillis) { dayKeyForMillis(uiState.nowMillis) }

    val filteredActivities = remember(uiState.activities, selectedDayKey) {
        if (selectedDayKey == null) {
            uiState.activities.filter { !it.isCompleted }
        } else {
            activitiesByDay[selectedDayKey].orEmpty()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionHeader(
                title = "Fotbollskalender",
                subtitle = "Matcher, träningar, gympass och påminnelser",
                trailing = {
                    IconButton(
                        onClick = onOpenNotificationSettings,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(SlateCard)
                            .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                            .testTag("calendar_notif_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsActive,
                            contentDescription = "Notis- och ljudinställningar",
                            tint = primary
                        )
                    }
                }
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showAddDialog = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("calendar_add_activity_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Lägg till aktivitet", style = MaterialTheme.typography.labelLarge)
                }

                if (selectedDayKey != null) {
                    OutlinedButton(
                        onClick = { selectedDayKey = null },
                        modifier = Modifier.height(48.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Visa alla")
                    }
                }
            }
        }

        // Månadskalender
        item {
            StadiumCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { displayedMonthOffset-- }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Föregående månad")
                    }
                    Text(
                        text = monthTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                    IconButton(onClick = { displayedMonthOffset++ }) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Nästa månad")
                    }
                }

                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    listOf("Mån", "Tis", "Ons", "Tor", "Fre", "Lör", "Sön").forEach { dayName ->
                        Text(
                            text = dayName,
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))

                val daysInMonth = monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                val firstDayOfWeek = monthCal.get(Calendar.DAY_OF_WEEK)
                // Måndag = 0, Söndag = 6
                val leadingEmpty = ((firstDayOfWeek - Calendar.MONDAY) + 7) % 7
                val totalCells = leadingEmpty + daysInMonth
                val rows = (totalCells + 6) / 7

                for (r in 0 until rows) {
                    Row(modifier = Modifier.fillMaxWidth()) {
                        for (c in 0 until 7) {
                            val cellIndex = r * 7 + c
                            val dayNum = cellIndex - leadingEmpty + 1
                            if (dayNum in 1..daysInMonth) {
                                val cellCal = (monthCal.clone() as Calendar).apply {
                                    set(Calendar.DAY_OF_MONTH, dayNum)
                                }
                                val key = dayKeyForMillis(cellCal.timeInMillis)
                                val dayActivities = activitiesByDay[key].orEmpty()
                                val isToday = key == todayKey
                                val isSelected = key == selectedDayKey

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .aspectRatio(1f)
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when {
                                                isSelected -> primary.copy(alpha = 0.25f)
                                                isToday -> CarbonSurface
                                                else -> Color.Transparent
                                            }
                                        )
                                        .border(
                                            width = if (isSelected || isToday) 1.dp else 0.dp,
                                            color = when {
                                                isSelected -> primary
                                                isToday -> primary.copy(alpha = 0.5f)
                                                else -> Color.Transparent
                                            },
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            selectedDayKey = if (selectedDayKey == key) null else key
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(
                                            text = "$dayNum",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = if (isToday || isSelected) FontWeight.Bold else FontWeight.Normal
                                            ),
                                            color = if (isSelected) primary else TextPrimary
                                        )
                                        if (dayActivities.isNotEmpty()) {
                                            Spacer(Modifier.height(2.dp))
                                            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                                dayActivities.take(3).forEach { act ->
                                                    Box(
                                                        modifier = Modifier
                                                            .size(5.dp)
                                                            .clip(CircleShape)
                                                            .background(activityTypeColor(ActivityType.fromName(act.type), primary))
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            } else {
                                Spacer(modifier = Modifier.weight(1f).aspectRatio(1f))
                            }
                        }
                    }
                }
            }
        }

        // Aktivitetslista
        item {
            SectionHeader(
                title = if (selectedDayKey == null) "Kommande aktiviteter" else "Aktiviteter vald dag",
                subtitle = "${filteredActivities.size} aktiviteter"
            )
        }

        if (filteredActivities.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Filled.CalendarMonth,
                    title = "Kalendern är tom här",
                    description = "Tryck på \"Lägg till aktivitet\" för att planera träningar, matcher, turneringar eller gympass."
                )
            }
        } else {
            items(filteredActivities, key = { it.id }) { activity ->
                ActivityItemCard(
                    activity = activity,
                    nowMillis = uiState.nowMillis,
                    onComplete = { onCompleteActivity(activity) },
                    onDelete = { onDeleteActivity(activity.id) }
                )
            }
        }
    }

    if (showAddDialog) {
        AddCalendarActivityDialog(
            onSave = { newAct ->
                onAddActivity(newAct)
                showAddDialog = false
            },
            onDismiss = { showAddDialog = false }
        )
    }
}

@Composable
private fun ActivityItemCard(
    activity: CalendarActivityEntity,
    nowMillis: Long,
    onComplete: () -> Unit,
    onDelete: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val type = ActivityType.fromName(activity.type)
    val typeColor = activityTypeColor(type, primary)
    val isFuture = activity.startTimeMillis > nowMillis

    StadiumCard(borderColor = typeColor.copy(alpha = 0.5f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(typeColor.copy(alpha = 0.16f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = type.swedishLabel.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = typeColor
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = activity.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${SwedishFormatters.formatDateTime(activity.startTimeMillis)} (${activity.durationMinutes} min)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                if (activity.location.isNotBlank()) {
                    Spacer(Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(text = activity.location, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
                if (activity.notes.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(text = activity.notes, style = MaterialTheme.typography.bodySmall, color = TextMuted)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                if (isFuture && !activity.isCompleted) {
                    Text(
                        text = SwedishFormatters.formatCountdown(activity.startTimeMillis, nowMillis),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = typeColor
                    )
                    Text(text = "kvar", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Ta bort aktivitet", tint = TextMuted)
                }
            }
        }

        if (!activity.isCompleted) {
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val remindersActive = listOfNotNull(
                    if (activity.notify1h) "1t" else null,
                    if (activity.notify30m) "30m" else null,
                    if (activity.notify15m) "15m" else null
                ).joinToString(", ")
                Text(
                    text = if (remindersActive.isNotBlank()) "Påminnelser: $remindersActive innan" else "Inga påminnelser",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )

                OutlinedButton(
                    onClick = onComplete,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Slutför", style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Composable
private fun AddCalendarActivityDialog(
    onSave: (CalendarActivityEntity) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(ActivityType.TRÄNING) }
    var title by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var durationText by remember { mutableStateOf("90") }
    var notes by remember { mutableStateOf("") }
    var daysFromToday by remember { mutableIntStateOf(0) }
    var hour by remember { mutableIntStateOf(18) }
    var minute by remember { mutableIntStateOf(0) }
    var isAway by remember { mutableStateOf(false) }
    var notify1h by remember { mutableStateOf(true) }
    var notify30m by remember { mutableStateOf(true) }
    var notify15m by remember { mutableStateOf(true) }

    val primary = MaterialTheme.colorScheme.primary

    val targetCal = remember(daysFromToday, hour, minute) {
        Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, daysFromToday)
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CarbonSurface)
                .border(1.dp, BorderSubtle, RoundedCornerShape(24.dp))
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "NY AKTIVITET",
                style = MaterialTheme.typography.headlineMedium,
                color = primary
            )

            Text("Typ av aktivitet", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ActivityType.entries.forEach { t ->
                    FilterChip(
                        selected = selectedType == t,
                        onClick = { selectedType = t },
                        label = { Text(t.swedishLabel) }
                    )
                }
            }

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Titel / Aktivitetsnamn") },
                placeholder = { Text("t.ex. Kvällsträning eller Seriematch") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calendar_title_input")
            )

            // Datumväljare
            Text("Datum: ${SwedishFormatters.formatDate(targetCal.timeInMillis)}", style = MaterialTheme.typography.labelMedium, color = primary)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(0 to "Idag", 1 to "Imorgon", 2 to "+2 dagar", 3 to "+3 dagar", 7 to "+1 vecka").forEach { (offset, label) ->
                    FilterChip(
                        selected = daysFromToday == offset,
                        onClick = { daysFromToday = offset },
                        label = { Text(label) }
                    )
                }
                FilterChip(
                    selected = daysFromToday !in listOf(0, 1, 2, 3, 7),
                    onClick = { daysFromToday++ },
                    label = { Text("+1 dag") }
                )
            }

            // Tidväljare
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format(Locale("sv", "SE"), "Starttid: %02d:%02d", hour, minute),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { hour = (hour + 23) % 24 }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("-1t")
                    }
                    OutlinedButton(onClick = { hour = (hour + 1) % 24 }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("+1t")
                    }
                    OutlinedButton(onClick = { minute = (minute + 15) % 60 }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("+15m")
                    }
                }
            }

            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Plats / Arena") },
                placeholder = { Text("t.ex. Konstgräsplan 1") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = durationText,
                onValueChange = { durationText = it.filter { c -> c.isDigit() } },
                label = { Text("Varaktighet (minuter)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Anteckningar") },
                placeholder = { Text("Ta med benskydd, vattenflaska...") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            if (selectedType == ActivityType.MATCH || selectedType == ActivityType.TURNERING) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Bortamatch", style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    Switch(checked = isAway, onCheckedChange = { isAway = it })
                }
            }

            Text("Automatiska påminnelser", style = MaterialTheme.typography.labelMedium, color = TextSecondary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notify1h, onCheckedChange = { notify1h = it })
                Text("1 timme innan", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notify30m, onCheckedChange = { notify30m = it })
                Text("30 min innan", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = notify15m, onCheckedChange = { notify15m = it })
                Text("15 min innan", style = MaterialTheme.typography.bodySmall, color = TextPrimary)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text("Avbryt")
                }
                Button(
                    onClick = {
                        val finalTitle = title.trim().ifBlank { selectedType.swedishLabel }
                        val mins = durationText.toIntOrNull()?.coerceIn(10, 480) ?: 90
                        onSave(
                            CalendarActivityEntity(
                                title = finalTitle,
                                type = selectedType.name,
                                startTimeMillis = targetCal.timeInMillis,
                                durationMinutes = mins,
                                location = location.trim(),
                                notes = notes.trim(),
                                isAwayMatch = isAway,
                                notify1h = notify1h,
                                notify30m = notify30m,
                                notify15m = notify15m
                            )
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("calendar_save_activity_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = primary, contentColor = ObsidianBlack)
                ) {
                    Text("SPARA", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

private fun dayKeyForMillis(millis: Long): String {
    val cal = Calendar.getInstance().apply { timeInMillis = millis }
    return "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)}-${cal.get(Calendar.DAY_OF_MONTH)}"
}

private fun activityTypeColor(type: ActivityType, primary: Color): Color = when (type) {
    ActivityType.TRÄNING -> primary
    ActivityType.MATCH -> ChampionGold
    ActivityType.TURNERING -> CyberBlue
    ActivityType.GYMPASS -> RarityLegendary
    ActivityType.EGEN -> TextPrimary
}
