package com.example.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.CalendarActivityEntity
import com.example.data.local.NotificationPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ReminderScheduler {

    const val EXTRA_ACTIVITY_ID = "extra_activity_id"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_TYPE = "extra_type"
    const val EXTRA_MINUTES_BEFORE = "extra_minutes_before"
    const val EXTRA_TIME_TEXT = "extra_time_text"
    const val EXTRA_LOCATION = "extra_location"

    private val timeFormatter = SimpleDateFormat("HH:mm", Locale("sv", "SE"))

    fun scheduleActivityReminders(
        context: Context,
        activity: CalendarActivityEntity,
        prefs: NotificationPreferences
    ) {
        cancelActivityReminders(context, activity.id)
        if (!prefs.remindersEnabled || activity.isCompleted) return

        val now = System.currentTimeMillis()
        val timeText = timeFormatter.format(Date(activity.startTimeMillis))

        val offsets = buildList {
            if (activity.notify1h && prefs.notify1hEnabled) add(60)
            if (activity.notify30m && prefs.notify30mEnabled) add(30)
            if (activity.notify15m && prefs.notify15mEnabled) add(15)
        }

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        for (minutesBefore in offsets) {
            val triggerAt = activity.startTimeMillis - minutesBefore * 60_000L
            if (triggerAt <= now) continue

            val requestCode = requestCodeFor(activity.id, minutesBefore)
            val intent = Intent(context, ReminderReceiver::class.java).apply {
                putExtra(EXTRA_ACTIVITY_ID, activity.id)
                putExtra(EXTRA_TITLE, activity.title)
                putExtra(EXTRA_TYPE, activity.type)
                putExtra(EXTRA_MINUTES_BEFORE, minutesBefore)
                putExtra(EXTRA_TIME_TEXT, timeText)
                putExtra(EXTRA_LOCATION, activity.location)
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                    )
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerAt,
                        pendingIntent
                    )
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                }
            } catch (_: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
                }
            }
        }
    }

    fun cancelActivityReminders(context: Context, activityId: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        for (minutesBefore in listOf(60, 30, 15)) {
            val intent = Intent(context, ReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                requestCodeFor(activityId, minutesBefore),
                intent,
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (pendingIntent != null) {
                alarmManager.cancel(pendingIntent)
                pendingIntent.cancel()
            }
        }
    }

    private fun requestCodeFor(activityId: Long, minutesBefore: Int): Int {
        return ((activityId % 100_000L).toInt() * 100) + minutesBefore
    }
}
