package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.NotificationPreferences
import com.example.domain.ActivityType

object NotificationHelper {

    const val CHANNEL_ACHIEVEMENTS = "fc_achievements"
    const val CHANNEL_TIMER = "fc_timer_done"

    fun ensureChannels(context: Context, prefs: NotificationPreferences) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        // Dynamiska kanaler per ljudval så att användarens valda ljud alltid används i bakgrunden
        val matchChannelId = channelIdFor(true, prefs.matchSoundId, prefs.vibrationEnabled)
        if (nm.getNotificationChannel(matchChannelId) == null) {
            val ch = NotificationChannel(
                matchChannelId,
                "Matchpåminnelser",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Påminnelser inför matcher och turneringar"
                setSound(SoundPlayer.resolveSoundUri(context, prefs.matchSoundId), audioAttrs)
                enableVibration(prefs.vibrationEnabled)
                if (prefs.vibrationEnabled) {
                    vibrationPattern = longArrayOf(0, 250, 120, 300)
                }
            }
            nm.createNotificationChannel(ch)
        }

        val trainingChannelId = channelIdFor(false, prefs.trainingSoundId, prefs.vibrationEnabled)
        if (nm.getNotificationChannel(trainingChannelId) == null) {
            val ch = NotificationChannel(
                trainingChannelId,
                "Träningspåminnelser",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Påminnelser inför träningspass, gympass och aktiviteter"
                setSound(SoundPlayer.resolveSoundUri(context, prefs.trainingSoundId), audioAttrs)
                enableVibration(prefs.vibrationEnabled)
                if (prefs.vibrationEnabled) {
                    vibrationPattern = longArrayOf(0, 160, 100, 160)
                }
            }
            nm.createNotificationChannel(ch)
        }

        if (nm.getNotificationChannel(CHANNEL_ACHIEVEMENTS) == null) {
            val ch = NotificationChannel(
                CHANNEL_ACHIEVEMENTS,
                "Upplåsta prestationer",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notiser när du låser upp nya prestationer och troféer"
                setSound(SoundPlayer.resolveSoundUri(context, "achievement_fanfare"), audioAttrs)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 120, 80, 120, 80, 250)
            }
            nm.createNotificationChannel(ch)
        }

        if (nm.getNotificationChannel(CHANNEL_TIMER) == null) {
            val ch = NotificationChannel(
                CHANNEL_TIMER,
                "Match- & träningstimer",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Signaler när nedräkning eller halvlek är klar"
                setSound(SoundPlayer.resolveSoundUri(context, "urgent_horn"), audioAttrs)
                enableVibration(true)
            }
            nm.createNotificationChannel(ch)
        }
    }

    fun channelIdFor(isMatch: Boolean, soundId: String, vibrate: Boolean): String {
        val kind = if (isMatch) "match" else "train"
        val vib = if (vibrate) "v1" else "v0"
        return "fc_${kind}_${soundId}_$vib"
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun showActivityReminder(
        context: Context,
        prefs: NotificationPreferences,
        notificationId: Int,
        activityTitle: String,
        activityType: ActivityType,
        minutesBefore: Int,
        timeFormatted: String,
        location: String
    ) {
        if (!hasNotificationPermission(context)) return
        ensureChannels(context, prefs)

        val isMatch = activityType == ActivityType.MATCH || activityType == ActivityType.TURNERING
        val soundId = when {
            minutesBefore <= 15 -> prefs.urgentSoundId
            isMatch -> prefs.matchSoundId
            else -> prefs.trainingSoundId
        }
        val channelId = channelIdFor(isMatch, soundId, prefs.vibrationEnabled)

        val headline = when {
            minutesBefore >= 60 -> if (isMatch) "MATCH OM 1 TIMME!" else "TRÄNING OM 1 TIMME!"
            minutesBefore >= 30 -> if (isMatch) "MATCH OM 30 MINUTER!" else "TRÄNING OM 30 MINUTER!"
            else -> "15 MINUTER KVAR. DAGS ATT GÖRA SIG REDO!"
        }

        val locationText = if (location.isNotBlank()) " • Plats: $location" else ""
        val body = "$activityTitle • Kl $timeFormatted$locationText • Nedräkning: $minutesBefore min"

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(headline)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .setSound(SoundPlayer.resolveSoundUri(context, soundId))

        if (prefs.vibrationEnabled) {
            builder.setVibrate(longArrayOf(0, 220, 100, 260))
        }

        NotificationManagerCompat.from(context).notify(notificationId, builder.build())
    }

    fun showAchievementUnlocked(
        context: Context,
        prefs: NotificationPreferences,
        achievementTitle: String,
        rarityLabel: String,
        xpReward: Int
    ) {
        if (!prefs.achievementNotificationsEnabled || !hasNotificationPermission(context)) return
        ensureChannels(context, prefs)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentIntent = PendingIntent.getActivity(
            context,
            achievementTitle.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val body = "$achievementTitle ($rarityLabel) upplåst! +$xpReward XP tillagd i din karriär."
        val notification = NotificationCompat.Builder(context, CHANNEL_ACHIEVEMENTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("NY PRESTATION UPPLÅST!")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent)
            .build()

        NotificationManagerCompat.from(context).notify(
            10000 + (achievementTitle.hashCode() and 0x7FFF),
            notification
        )
    }

    fun showTimerComplete(context: Context, title: String, message: String) {
        if (!hasNotificationPermission(context)) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm.getNotificationChannel(CHANNEL_TIMER) == null) {
            val audioAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_TIMER, "Match- & träningstimer", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(SoundPlayer.resolveSoundUri(context, "urgent_horn"), audioAttrs)
                    enableVibration(true)
                }
            )
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_TIMER)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify(20001, notification)
    }
}
