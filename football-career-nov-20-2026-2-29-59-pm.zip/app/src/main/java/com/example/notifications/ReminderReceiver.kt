package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.PreferencesRepository
import com.example.domain.ActivityType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pendingResult = goAsync()
        val activityId = intent.getLongExtra(ReminderScheduler.EXTRA_ACTIVITY_ID, 0L)
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Kommande aktivitet"
        val typeName = intent.getStringExtra(ReminderScheduler.EXTRA_TYPE) ?: ActivityType.TRÄNING.name
        val minutesBefore = intent.getIntExtra(ReminderScheduler.EXTRA_MINUTES_BEFORE, 15)
        val timeText = intent.getStringExtra(ReminderScheduler.EXTRA_TIME_TEXT) ?: "--:--"
        val location = intent.getStringExtra(ReminderScheduler.EXTRA_LOCATION) ?: ""

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = PreferencesRepository(context.applicationContext).getNotificationPreferencesOnce()
                if (!prefs.remindersEnabled) return@launch

                val allowedByOffset = when (minutesBefore) {
                    60 -> prefs.notify1hEnabled
                    30 -> prefs.notify30mEnabled
                    15 -> prefs.notify15mEnabled
                    else -> true
                }
                if (!allowedByOffset) return@launch

                val notificationId = ((activityId % 100_000L).toInt() * 100) + minutesBefore
                NotificationHelper.showActivityReminder(
                    context = context.applicationContext,
                    prefs = prefs,
                    notificationId = notificationId,
                    activityTitle = title,
                    activityType = ActivityType.fromName(typeName),
                    minutesBefore = minutesBefore,
                    timeFormatted = timeText,
                    location = location
                )
            } finally {
                pendingResult.finish()
            }
        }
    }
}
