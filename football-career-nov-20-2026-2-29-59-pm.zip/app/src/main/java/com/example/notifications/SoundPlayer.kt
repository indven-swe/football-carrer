package com.example.notifications

import android.content.ContentResolver
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.R
import com.example.domain.NotificationSoundOption

object SoundPlayer {

    private var activePlayer: MediaPlayer? = null

    fun resolveSoundUri(context: Context, soundOptionId: String): Uri {
        val option = NotificationSoundOption.fromId(soundOptionId)
        val rawResId = when (option) {
            NotificationSoundOption.WHISTLE -> R.raw.sound_match_whistle
            NotificationSoundOption.TRAINING_PULSE -> R.raw.sound_training_pulse
            NotificationSoundOption.URGENT_HORN -> R.raw.sound_urgent_horn
            NotificationSoundOption.ACHIEVEMENT_FANFARE -> R.raw.sound_achievement_fanfare
            NotificationSoundOption.SYSTEM_DEFAULT -> null
        }
        return if (rawResId != null) {
            Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/$rawResId")
        } else {
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
    }

    fun playPreview(context: Context, soundOptionId: String) {
        try {
            activePlayer?.release()
            activePlayer = null
            val uri = resolveSoundUri(context, soundOptionId)
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(context, uri)
                setOnCompletionListener {
                    it.release()
                    if (activePlayer === it) activePlayer = null
                }
                prepare()
                start()
            }
            activePlayer = player
        } catch (_: Exception) {
            // Ignorera uppspelningsfel på enheter utan ljudhårdvara
        }
    }

    fun vibratePulse(context: Context, pattern: LongArray = longArrayOf(0, 180, 90, 220)) {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            } ?: return

            if (!vibrator.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(pattern, -1)
            }
        } catch (_: Exception) {
            // Säker fallback
        }
    }
}
