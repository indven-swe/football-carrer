package com.example.notifications

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.FootballCareerDatabase
import com.example.data.local.PreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FootballCareerDatabase.getInstance(context.applicationContext)
                val prefs = PreferencesRepository(context.applicationContext).getNotificationPreferencesOnce()
                val futureActivities = db.calendarActivityDao().getFutureActivitiesOnce(System.currentTimeMillis())
                futureActivities.forEach { activity ->
                    ReminderScheduler.scheduleActivityReminders(context.applicationContext, activity, prefs)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
