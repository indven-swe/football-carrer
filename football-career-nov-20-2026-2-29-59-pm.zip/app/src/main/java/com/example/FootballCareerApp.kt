package com.example

import android.app.Application
import com.example.data.local.FootballCareerDatabase
import com.example.data.local.PreferencesRepository
import com.example.data.repository.CareerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class FootballCareerApp : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { FootballCareerDatabase.getInstance(this) }
    val preferencesRepository by lazy { PreferencesRepository(this) }
    val careerRepository by lazy {
        CareerRepository(
            context = applicationContext,
            db = database,
            prefsRepo = preferencesRepository
        )
    }

    override fun onCreate() {
        super.onCreate()
        appScope.launch {
            careerRepository.ensureInitialized()
        }
    }
}
