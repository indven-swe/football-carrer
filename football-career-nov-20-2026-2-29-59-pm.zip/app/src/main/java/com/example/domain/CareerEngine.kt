package com.example.domain

import com.example.data.local.AchievementEntity
import com.example.data.local.MatchRecordEntity
import com.example.data.local.PlayerProfileEntity
import com.example.data.local.SeasonSummaryEntity
import com.example.data.local.TrainingRecordEntity
import java.util.Calendar
import kotlin.math.roundToInt
import kotlin.random.Random

object CareerEngine {

    /**
     * Beräknar totalt XP som krävs för att nå en viss nivå (1..100).
     * Nivå 1 = 0 XP, Nivå 2 = 100 XP, Nivå 3 = 230 XP, osv.
     */
    fun totalXpForLevel(level: Int): Int {
        val clamped = level.coerceIn(1, 100)
        if (clamped <= 1) return 0
        var sum = 0
        for (l in 1 until clamped) {
            sum += 100 + (l - 1) * 35
        }
        return sum
    }

    fun calculateLevelProgress(totalXp: Int): LevelProgress {
        val safeXp = totalXp.coerceAtLeast(0)
        var level = 1
        while (level < 100 && safeXp >= totalXpForLevel(level + 1)) {
            level++
        }
        val currentStart = totalXpForLevel(level)
        val nextXp = if (level >= 100) currentStart + 1000 else totalXpForLevel(level + 1)
        val span = (nextXp - currentStart).coerceAtLeast(1)
        val fraction = if (level >= 100) 1f else ((safeXp - currentStart).toFloat() / span).coerceIn(0f, 1f)
        return LevelProgress(
            level = level,
            totalXp = safeXp,
            currentLevelStartXp = currentStart,
            nextLevelXp = nextXp,
            progressFraction = fraction
        )
    }

    fun calculateOvr(profile: PlayerProfileEntity): Int {
        val avg = (profile.pace + profile.shooting + profile.passing + profile.dribbling + profile.defending + profile.physical) / 6.0
        val levelBonus = (profile.level - 1) * 0.25
        return (avg + levelBonus).roundToInt().coerceIn(45, 99)
    }

    fun evolveCardRarityIfNeeded(ovr: Int, currentRarity: String): String {
        val current = CardRarityTier.fromName(currentRarity)
        val autoTier = when {
            ovr >= 90 -> CardRarityTier.LEGENDARISK
            ovr >= 83 -> CardRarityTier.PLATINA
            ovr >= 75 -> CardRarityTier.GULD
            ovr >= 68 -> CardRarityTier.SILVER
            else -> CardRarityTier.BRONS
        }
        return if (autoTier.ordinal > current.ordinal) autoTier.name else current.name
    }

    fun applyTrainingGrowth(
        profile: PlayerProfileEntity,
        trainingType: TrainingType,
        intensity: TrainingIntensity,
        xpEarned: Int
    ): PlayerProfileEntity {
        val boost = when (intensity) {
            TrainingIntensity.LÅG -> 1
            TrainingIntensity.MEDEL -> 1
            TrainingIntensity.HÖG -> 2
            TrainingIntensity.MAXIMAL -> 2
        }
        var pace = profile.pace
        var shooting = profile.shooting
        var passing = profile.passing
        var dribbling = profile.dribbling
        var defending = profile.defending
        var physical = profile.physical

        when (trainingType) {
            TrainingType.TEKNIK -> {
                dribbling = (dribbling + boost).coerceAtMost(99)
                passing = (passing + 1).coerceAtMost(99)
            }
            TrainingType.SKOTT -> {
                shooting = (shooting + boost).coerceAtMost(99)
            }
            TrainingType.PASSNING -> {
                passing = (passing + boost).coerceAtMost(99)
            }
            TrainingType.DRIBBLING -> {
                dribbling = (dribbling + boost).coerceAtMost(99)
                pace = (pace + 1).coerceAtMost(99)
            }
            TrainingType.FYSIK -> {
                pace = (pace + boost).coerceAtMost(99)
                physical = (physical + 1).coerceAtMost(99)
            }
            TrainingType.GYMPASS -> {
                physical = (physical + boost).coerceAtMost(99)
                defending = (defending + 1).coerceAtMost(99)
            }
            TrainingType.TAKTIK -> {
                defending = (defending + boost).coerceAtMost(99)
                passing = (passing + 1).coerceAtMost(99)
            }
            TrainingType.ÅTERHÄMTNING -> {
                physical = (physical + 1).coerceAtMost(99)
            }
        }

        val newXp = profile.totalXp + xpEarned
        val newLevel = calculateLevelProgress(newXp).level
        val updated = profile.copy(
            totalXp = newXp,
            level = newLevel,
            pace = pace,
            shooting = shooting,
            passing = passing,
            dribbling = dribbling,
            defending = defending,
            physical = physical
        )
        val newOvr = calculateOvr(updated)
        return updated.copy(
            ovrRating = newOvr,
            cardRarity = evolveCardRarityIfNeeded(newOvr, updated.cardRarity)
        )
    }

    fun applyMatchGrowth(
        profile: PlayerProfileEntity,
        goals: Int,
        assists: Int,
        rating: Float,
        xpEarned: Int
    ): PlayerProfileEntity {
        var shooting = profile.shooting
        var passing = profile.passing
        var dribbling = profile.dribbling
        var defending = profile.defending
        var physical = profile.physical

        if (goals > 0) shooting = (shooting + 1).coerceAtMost(99)
        if (assists > 0) passing = (passing + 1).coerceAtMost(99)
        if (rating >= 8.0f) {
            dribbling = (dribbling + 1).coerceAtMost(99)
            defending = (defending + 1).coerceAtMost(99)
        }
        physical = (physical + 1).coerceAtMost(99)

        val newXp = profile.totalXp + xpEarned
        val newLevel = calculateLevelProgress(newXp).level
        val updated = profile.copy(
            totalXp = newXp,
            level = newLevel,
            shooting = shooting,
            passing = passing,
            dribbling = dribbling,
            defending = defending,
            physical = physical
        )
        val newOvr = calculateOvr(updated)
        return updated.copy(
            ovrRating = newOvr,
            cardRarity = evolveCardRarityIfNeeded(newOvr, updated.cardRarity)
        )
    }

    fun calculateMatchXp(goals: Int, assists: Int, isManOfTheMatch: Boolean): Int {
        val base = 150
        val goalXp = goals * 50
        val assistXp = assists * 40
        val motmBonus = if (isManOfTheMatch) 50 else 0
        return base + goalXp + assistXp + motmBonus
    }

    fun calculateTrainingXp(type: TrainingType, intensity: TrainingIntensity): Int {
        val base = type.xpReward
        val intensityBonus = when (intensity) {
            TrainingIntensity.LÅG -> 0
            TrainingIntensity.MEDEL -> 10
            TrainingIntensity.HÖG -> 20
            TrainingIntensity.MAXIMAL -> 35
        }
        return base + intensityBonus
    }

    data class AchievementEvaluationResult(
        val updatedAchievements: List<AchievementEntity>,
        val newlyUnlocked: List<AchievementEntity>
    )

    fun evaluateAchievements(
        currentList: List<AchievementEntity>,
        profile: PlayerProfileEntity,
        matches: List<MatchRecordEntity>,
        trainings: List<TrainingRecordEntity>,
        seasons: List<SeasonSummaryEntity>,
        hadComebackGap: Boolean
    ): AchievementEvaluationResult {
        val totalTrainings = trainings.size
        val totalMatches = matches.size
        val totalGoals = matches.sumOf { it.goals }
        val totalAssists = matches.sumOf { it.assists }
        val hattricks = matches.count { it.goals >= 3 }
        val awayMatches = matches.count { it.isAway }
        val hasDecisiveGoal = matches.any { it.isDecisiveGoal }
        val maxSameSkillTraining = trainings
            .groupBy { it.skillFocused.ifBlank { it.type } }
            .maxOfOrNull { it.value.size } ?: 0

        val hasMorningTraining = trainings.any { record ->
            val cal = Calendar.getInstance().apply { timeInMillis = record.dateEpochMillis }
            cal.get(Calendar.HOUR_OF_DAY) < 8
        }

        val maxTrainingsInOneWeek = trainings.groupBy { record ->
            val cal = Calendar.getInstance().apply { timeInMillis = record.dateEpochMillis }
            "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.WEEK_OF_YEAR)}"
        }.maxOfOrNull { it.value.size } ?: 0

        val now = System.currentTimeMillis()
        val newlyUnlocked = mutableListOf<AchievementEntity>()

        val updated = currentList.map { ach ->
            val progress = when (ach.key) {
                "first_touch" -> totalTrainings.coerceAtMost(1)
                "workhorse" -> totalTrainings.coerceAtMost(10)
                "matchday" -> totalMatches.coerceAtMost(5)
                "goal_machine" -> totalGoals.coerceAtMost(10)
                "playmaker" -> totalAssists.coerceAtMost(10)
                "ironman" -> profile.longestStreakDays.coerceAtMost(30)
                "hattrick_hero" -> hattricks.coerceAtMost(1)
                "comeback" -> if (ach.isUnlocked || hadComebackGap) 1 else 0
                "veteran" -> totalMatches.coerceAtMost(50)
                "club_100" -> profile.totalXp.coerceAtMost(100)
                "hattrick_collector" -> hattricks.coerceAtMost(3)
                "morning_star" -> if (hasMorningTraining) 1 else 0
                "away_warrior" -> awayMatches.coerceAtMost(5)
                "perfect_week" -> maxTrainingsInOneWeek.coerceAtMost(3)
                "match_winner" -> if (hasDecisiveGoal) 1 else 0
                "tech_master" -> maxSameSkillTraining.coerceAtMost(10)
                "loyalty" -> if (seasons.isNotEmpty()) 1 else 0
                "big_match_player" -> totalMatches.coerceAtMost(10)
                "unstoppable" -> profile.totalXp.coerceAtMost(500)
                "football_maniac" -> totalTrainings.coerceAtMost(100)
                else -> ach.progressCurrent
            }

            val shouldUnlock = ach.isUnlocked || progress >= ach.progressTarget
            if (shouldUnlock && !ach.isUnlocked) {
                val unlockedAch = ach.copy(
                    isUnlocked = true,
                    unlockedAtMillis = now,
                    progressCurrent = ach.progressTarget
                )
                newlyUnlocked.add(unlockedAch)
                unlockedAch
            } else {
                ach.copy(progressCurrent = progress)
            }
        }

        return AchievementEvaluationResult(updated, newlyUnlocked)
    }

    fun computePersonalRecords(
        profile: PlayerProfileEntity,
        matches: List<MatchRecordEntity>,
        trainings: List<TrainingRecordEntity>
    ): List<PersonalRecord> {
        val mostGoals = matches.maxByOrNull { it.goals }
        val highestRating = matches.maxByOrNull { it.performanceRating }
        val longestTraining = trainings.maxByOrNull { it.durationMinutes }
        val hattricks = matches.count { it.goals >= 3 }

        return listOf(
            PersonalRecord(
                title = "Flest mål i en match",
                value = if (mostGoals != null) "${mostGoals.goals} mål" else "0 mål",
                subtitle = if (mostGoals != null) "Mot ${mostGoals.opponent}" else "Ingen match loggad ännu"
            ),
            PersonalRecord(
                title = "Högsta matchbetyg",
                value = if (highestRating != null) String.format("%.1f / 10", highestRating.performanceRating) else "–",
                subtitle = if (highestRating != null) "Mot ${highestRating.opponent}" else "Spela matcher för att sätta rekord"
            ),
            PersonalRecord(
                title = "Längsta träningssvit",
                value = "${profile.longestStreakDays} dagar",
                subtitle = "Nuvarande svit: ${profile.activeStreakDays} dagar"
            ),
            PersonalRecord(
                title = "Längsta träningspass",
                value = if (longestTraining != null) "${longestTraining.durationMinutes} min" else "0 min",
                subtitle = longestTraining?.let { TrainingType.fromName(it.type).swedishName } ?: "Inget pass loggat ännu"
            ),
            PersonalRecord(
                title = "Totalt antal hattricks",
                value = "$hattricks st",
                subtitle = "3+ mål i samma match"
            )
        )
    }

    fun generatePackReward(): PackRewardResult {
        val roll = Random.nextInt(100)
        return when {
            roll >= 90 -> PackRewardResult(
                title = "Legendarisk Karriärboost",
                subtitle = "En sällsynt mästarbelöning som höjer din aura på planen!",
                rarity = AchievementRarity.LEGENDARISK,
                xpBonus = 250,
                attributeBoostLabel = "+2 Snabbhet & +2 Skott"
            )
            roll >= 70 -> PackRewardResult(
                title = "Platina Teknikkort",
                subtitle = "Elitnivå på bollkontroll och spelförståelse.",
                rarity = AchievementRarity.PLATINA,
                xpBonus = 175,
                attributeBoostLabel = "+2 Dribbling & +1 Passningar"
            )
            roll >= 40 -> PackRewardResult(
                title = "Guldpaket: Matchform",
                subtitle = "Skärpa i avsluten inför nästa stora matchdag.",
                rarity = AchievementRarity.GULD,
                xpBonus = 120,
                attributeBoostLabel = "+1 Skott & +1 Fysik"
            )
            else -> PackRewardResult(
                title = "Silverpaket: Träningsenergi",
                subtitle = "Extra drivkraft för veckans fotbollspass.",
                rarity = AchievementRarity.SILVER,
                xpBonus = 80,
                attributeBoostLabel = "+1 Passningar & +1 Försvar"
            )
        }
    }
}
