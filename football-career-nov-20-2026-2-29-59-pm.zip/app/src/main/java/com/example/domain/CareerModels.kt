package com.example.domain

enum class ActivityType(val swedishLabel: String, val defaultXp: Int) {
    TRÄNING("Fotbollsträning", 100),
    MATCH("Match", 150),
    TURNERING("Turnering", 200),
    GYMPASS("Gympass", 75),
    EGEN("Egen aktivitet", 50);

    companion object {
        fun fromName(name: String): ActivityType = entries.find { it.name == name } ?: TRÄNING
    }
}

enum class PlayerPosition(val code: String, val swedishName: String) {
    MV("MV", "Målvakt"),
    MB("MB", "Mittback"),
    HB("HB", "Högerback"),
    VB("VB", "Vänsterback"),
    CDM("CDM", "Defensiv mittfältare"),
    CM("CM", "Central mittfältare"),
    CAM("CAM", "Offensiv mittfältare"),
    HY("HY", "Höger ytter"),
    VY("VY", "Vänster ytter"),
    ANF("ANF", "Anfallare");

    companion object {
        fun fromCode(code: String): PlayerPosition = entries.find { it.code == code } ?: CM
    }
}

enum class PreferredFoot(val swedishLabel: String) {
    HÖGER("Höger"),
    VÄNSTER("Vänster"),
    BÅDA("Båda fötterna");

    companion object {
        fun fromName(name: String): PreferredFoot = entries.find { it.name == name } ?: HÖGER
    }
}

enum class CardDesignStyle(val swedishName: String) {
    FUTURISTISK("Futuristisk sköld"),
    KLASSISK("Klassisk EA FC"),
    HEXAGON("Hexagon Cyber"),
    IKON("Legendarisk Ikon");

    companion object {
        fun fromName(name: String): CardDesignStyle = entries.find { it.name == name } ?: FUTURISTISK
    }
}

enum class CardBackgroundStyle(val swedishName: String) {
    KOLFIBER("Svart kolfiber"),
    NEON_STADION("Neonstadion"),
    GULDMETALL("Guldmetall"),
    GALAX("Kosmisk obsidian");

    companion object {
        fun fromName(name: String): CardBackgroundStyle = entries.find { it.name == name } ?: KOLFIBER
    }
}

enum class CardBorderStyle(val swedishName: String) {
    NEON_GLÖD("Neonglöd"),
    DUBBEL_METALL("Dubbel metallram"),
    PRISMATISK("Prismatisk kant"),
    MINIMAL("Ren skarp kant");

    companion object {
        fun fromName(name: String): CardBorderStyle = entries.find { it.name == name } ?: NEON_GLÖD
    }
}

enum class CardColorPalette(val swedishName: String) {
    NEONGRÖN("Neongrön"),
    MÄSTARGULD("Mästarguld"),
    CYBERBLÅ("Cyberblå"),
    PLATINA_VIT("Platinavit"),
    LEGENDARISK_LILA("Legendarisk lila");

    companion object {
        fun fromName(name: String): CardColorPalette = entries.find { it.name == name } ?: NEONGRÖN
    }
}

enum class CardRarityTier(val swedishName: String) {
    BRONS("Brons"),
    SILVER("Silver"),
    GULD("Guld"),
    PLATINA("Platina"),
    LEGENDARISK("Legendarisk");

    companion object {
        fun fromName(name: String): CardRarityTier = entries.find { it.name == name } ?: BRONS
    }
}

enum class AchievementRarity(val swedishName: String) {
    BRONS("Brons"),
    SILVER("Silver"),
    GULD("Guld"),
    PLATINA("Platina"),
    LEGENDARISK("Legendarisk");

    companion object {
        fun fromName(name: String): AchievementRarity = entries.find { it.name == name } ?: BRONS
    }
}

enum class TrainingType(val swedishName: String, val xpReward: Int) {
    TEKNIK("Teknik & bollkontroll", 100),
    SKOTT("Skott & avslut", 100),
    PASSNING("Passningsspel", 100),
    DRIBBLING("Dribbling & finter", 100),
    FYSIK("Kondition & sprint", 100),
    GYMPASS("Gympass & styrka", 75),
    TAKTIK("Taktik & spelförståelse", 100),
    ÅTERHÄMTNING("Stretchning & återhämtning", 80);

    companion object {
        fun fromName(name: String): TrainingType = entries.find { it.name == name } ?: TEKNIK
    }
}

enum class TrainingIntensity(val swedishName: String) {
    LÅG("Låg"),
    MEDEL("Medel"),
    HÖG("Hög"),
    MAXIMAL("Maximal");

    companion object {
        fun fromName(name: String): TrainingIntensity = entries.find { it.name == name } ?: HÖG
    }
}

enum class ChallengeCategory(val swedishName: String) {
    DAGLIG("Dagens utmaning"),
    VECKOVIS("Veckoutmaning"),
    SLUMPMÄSSIG("Slumpad utmaning");

    companion object {
        fun fromName(name: String): ChallengeCategory = entries.find { it.name == name } ?: DAGLIG
    }
}

enum class NotificationSoundOption(val id: String, val swedishName: String, val description: String) {
    WHISTLE("whistle", "Domarvissla & Chime", "Skarp arenaton för matchstart"),
    TRAINING_PULSE("training_pulse", "Träningspuls", "Rytmisk synthsignal för träningspass"),
    URGENT_HORN("urgent_horn", "Arenahorn", "Kraftfull signal inför avspark"),
    ACHIEVEMENT_FANFARE("achievement_fanfare", "Mästarfanfar", "Triumferande ackord för milstolpar"),
    SYSTEM_DEFAULT("system_default", "Standardnotis", "Enhetens standardsignal");

    companion object {
        fun fromId(id: String): NotificationSoundOption =
            entries.find { it.id == id } ?: TRAINING_PULSE
    }
}

data class LevelProgress(
    val level: Int,
    val totalXp: Int,
    val currentLevelStartXp: Int,
    val nextLevelXp: Int,
    val progressFraction: Float
)

data class PersonalRecord(
    val title: String,
    val value: String,
    val subtitle: String
)

data class PackRewardResult(
    val title: String,
    val subtitle: String,
    val rarity: AchievementRarity,
    val xpBonus: Int,
    val attributeBoostLabel: String
)
