package com.example.domain

import com.example.data.local.AchievementEntity
import com.example.data.local.ChallengeEntity

object AchievementDefinitions {

    fun createInitialAchievements(): List<AchievementEntity> = listOf(
        AchievementEntity(
            id = 1,
            key = "first_touch",
            title = "Första touchen",
            description = "Genomför ditt allra första träningspass i karriären.",
            rarity = AchievementRarity.BRONS.name,
            requirementText = "Genomför 1 träning",
            xpReward = 50,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 2,
            key = "workhorse",
            title = "Arbetsmyran",
            description = "Kontinuitet bygger stjärnor. Genomför 10 träningspass.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "Genomför 10 träningar",
            xpReward = 150,
            progressTarget = 10
        ),
        AchievementEntity(
            id = 3,
            key = "matchday",
            title = "Matchdag",
            description = "Ta klivet ut på planen och spela 5 matcher.",
            rarity = AchievementRarity.BRONS.name,
            requirementText = "Spela 5 matcher",
            xpReward = 100,
            progressTarget = 5
        ),
        AchievementEntity(
            id = 4,
            key = "goal_machine",
            title = "Målmaskinen",
            description = "Klinisk i straffområdet. Gör totalt 10 mål.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Gör 10 mål",
            xpReward = 250,
            progressTarget = 10
        ),
        AchievementEntity(
            id = 5,
            key = "playmaker",
            title = "Spelfördelaren",
            description = "Öppna upp försvaret med kirurgiska passningar.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Gör 10 assist",
            xpReward = 250,
            progressTarget = 10
        ),
        AchievementEntity(
            id = 6,
            key = "ironman",
            title = "Järnmannen",
            description = "Visa otrolig disciplin genom att vara aktiv i 30 dagar.",
            rarity = AchievementRarity.PLATINA.name,
            requirementText = "Var aktiv 30 dagar",
            xpReward = 500,
            progressTarget = 30
        ),
        AchievementEntity(
            id = 7,
            key = "hattrick_hero",
            title = "Hattrick-hjälten",
            description = "En oförglömlig insats med tre mål i samma match.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Gör 3 mål i en match",
            xpReward = 300,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 8,
            key = "comeback",
            title = "Comeback",
            description = "Alltid redo att resa sig. Återvänd efter 14 dagars inaktivitet.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "Återvänd efter 14 dagars paus",
            xpReward = 200,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 9,
            key = "veteran",
            title = "Veteranen",
            description = "En sann klubbikon på planen med 50 spelade matcher.",
            rarity = AchievementRarity.PLATINA.name,
            requirementText = "Spela 50 matcher",
            xpReward = 600,
            progressTarget = 50
        ),
        AchievementEntity(
            id = 10,
            key = "club_100",
            title = "100-klubben",
            description = "Första stora XP-milstolpen i din fotbollskarriär.",
            rarity = AchievementRarity.BRONS.name,
            requirementText = "Samla 100 XP",
            xpReward = 50,
            progressTarget = 100
        ),
        AchievementEntity(
            id = 11,
            key = "hattrick_collector",
            title = "Hattrick-samlaren",
            description = "Tre matchbollar i troférummet. Ren målskicklighet.",
            rarity = AchievementRarity.LEGENDARISK.name,
            requirementText = "Gör 3 hattricks",
            xpReward = 800,
            progressTarget = 3
        ),
        AchievementEntity(
            id = 12,
            key = "morning_star",
            title = "Morgonstjärnan",
            description = "Först på träningsplanen innan världen vaknar.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "Träna före klockan 08:00",
            xpReward = 150,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 13,
            key = "away_warrior",
            title = "Bortakrigaren",
            description = "Leverera på bortaplan framför motståndarfansen.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "Spela 5 bortamatcher",
            xpReward = 175,
            progressTarget = 5
        ),
        AchievementEntity(
            id = 14,
            key = "perfect_week",
            title = "Perfekta veckan",
            description = "Håll tempot uppe med 3 träningspass under samma vecka.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "3 träningar på en vecka",
            xpReward = 200,
            progressTarget = 3
        ),
        AchievementEntity(
            id = 15,
            key = "match_winner",
            title = "Matchhjälten",
            description = "Kliv fram när det gäller som mest och avgör matchen.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Gör ett avgörande mål",
            xpReward = 300,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 16,
            key = "tech_master",
            title = "Teknikmästaren",
            description = "Nöt detaljerna till perfektion. Träna samma teknik 10 gånger.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Samma teknikträningsfokus 10 gånger",
            xpReward = 300,
            progressTarget = 10
        ),
        AchievementEntity(
            id = 17,
            key = "loyalty",
            title = "Lojaliteten",
            description = "Bär klubbmärket med stolthet genom en hel avslutad säsong.",
            rarity = AchievementRarity.PLATINA.name,
            requirementText = "Genomför en hel säsong i samma klubb",
            xpReward = 500,
            progressTarget = 1
        ),
        AchievementEntity(
            id = 18,
            key = "big_match_player",
            title = "Stormatchspelaren",
            description = "Tio matcher i benen och rutinen växer för varje avspark.",
            rarity = AchievementRarity.GULD.name,
            requirementText = "Spela 10 matcher",
            xpReward = 250,
            progressTarget = 10
        ),
        AchievementEntity(
            id = 19,
            key = "unstoppable",
            title = "Ostoppbar",
            description = "Momentum på topp! Nå 500 XP i karriären.",
            rarity = AchievementRarity.SILVER.name,
            requirementText = "Nå 500 XP",
            xpReward = 150,
            progressTarget = 500
        ),
        AchievementEntity(
            id = 20,
            key = "football_maniac",
            title = "Fotbollstokig",
            description = "Total hängivenhet till sporten med 100 träningspass.",
            rarity = AchievementRarity.LEGENDARISK.name,
            requirementText = "Genomför 100 träningar",
            xpReward = 1000,
            progressTarget = 100
        )
    )

    data class ChallengeTemplate(
        val key: String,
        val title: String,
        val description: String,
        val category: ChallengeCategory,
        val targetCount: Int,
        val xpReward: Int
    )

    val dailyPool = listOf(
        ChallengeTemplate(
            key = "weak_foot",
            title = "Träna den svaga foten",
            description = "Logga ett träningspass eller skottpass med fokus på svag fot.",
            category = ChallengeCategory.DAGLIG,
            targetCount = 1,
            xpReward = 90
        ),
        ChallengeTemplate(
            key = "dribble_session",
            title = "Genomför ett dribblingspass",
            description = "Kör koner, riktningsförändringar och nära bollkontroll.",
            category = ChallengeCategory.DAGLIG,
            targetCount = 1,
            xpReward = 100
        ),
        ChallengeTemplate(
            key = "passing_precision",
            title = "Förbättra passningarna",
            description = "Slipa på förstatouch och krossbollar i ett pass.",
            category = ChallengeCategory.DAGLIG,
            targetCount = 1,
            xpReward = 95
        ),
        ChallengeTemplate(
            key = "stretch_recovery",
            title = "Stretchning och återhämtning",
            description = "Ta hand om kroppen med rörlighet och återhämtning.",
            category = ChallengeCategory.DAGLIG,
            targetCount = 1,
            xpReward = 75
        ),
        ChallengeTemplate(
            key = "complete_training",
            title = "Genomför ett träningspass",
            description = "Slutför valfritt träningspass eller gympass idag.",
            category = ChallengeCategory.DAGLIG,
            targetCount = 1,
            xpReward = 100
        )
    )

    val weeklyPool = listOf(
        ChallengeTemplate(
            key = "weekly_three_trainings",
            title = "Veckans träningsmål",
            description = "Genomför 3 träningspass den här veckan.",
            category = ChallengeCategory.VECKOVIS,
            targetCount = 3,
            xpReward = 220
        ),
        ChallengeTemplate(
            key = "weekly_register_match",
            title = "Registrera en match",
            description = "Spela och logga en match med fullständig statistik.",
            category = ChallengeCategory.VECKOVIS,
            targetCount = 1,
            xpReward = 180
        )
    )

    val randomPool = listOf(
        ChallengeTemplate(
            key = "rand_finishing",
            title = "50 avslut i krysset",
            description = "Träna avslut på halvvolley och placerade skott.",
            category = ChallengeCategory.SLUMPMÄSSIG,
            targetCount = 1,
            xpReward = 120
        ),
        ChallengeTemplate(
            key = "rand_sprint",
            title = "Explosiv snabbhet",
            description = "Genomför ett sprint- eller snabbhetspass på hög intensitet.",
            category = ChallengeCategory.SLUMPMÄSSIG,
            targetCount = 1,
            xpReward = 110
        ),
        ChallengeTemplate(
            key = "rand_first_touch",
            title = "Mästare på mottagning",
            description = "Kör 15 minuter väggpass och vändningar under press.",
            category = ChallengeCategory.SLUMPMÄSSIG,
            targetCount = 1,
            xpReward = 105
        ),
        ChallengeTemplate(
            key = "rand_core_power",
            title = "Bål & duellstyrka",
            description = "Kör ett gym- eller fyspass för bättre balans i närkamper.",
            category = ChallengeCategory.SLUMPMÄSSIG,
            targetCount = 1,
            xpReward = 115
        )
    )

    fun toEntity(template: ChallengeTemplate, epochDay: Long): ChallengeEntity = ChallengeEntity(
        title = template.title,
        description = template.description,
        category = template.category.name,
        targetCount = template.targetCount,
        currentCount = 0,
        xpReward = template.xpReward,
        isCompleted = false,
        assignedEpochDay = epochDay,
        challengeKey = template.key
    )
}
