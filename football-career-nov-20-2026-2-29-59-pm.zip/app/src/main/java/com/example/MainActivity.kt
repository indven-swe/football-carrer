package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.domain.AchievementRarity
import com.example.notifications.NotificationHelper
import com.example.ui.components.LogMatchDialog
import com.example.ui.components.LogTrainingDialog
import com.example.ui.components.NotificationSettingsDialog
import com.example.ui.components.PackOpeningDialog
import com.example.ui.components.SeasonSummaryDialog
import com.example.ui.components.rarityColor
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.CareerStatsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.StatsSubTab
import com.example.ui.screens.TrophyRoomScreen
import com.example.ui.theme.AppAccentTheme
import com.example.ui.theme.CarbonSurface
import com.example.ui.theme.FootballCareerTheme
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SlateCard
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.CareerViewModel
import com.example.ui.viewmodel.TimerViewModel
import kotlinx.coroutines.delay

sealed class AppDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    data object Start : AppDestination("start", "Start", Icons.Filled.Home, Icons.Outlined.Home, "nav_start")
    data object Calendar : AppDestination("kalender", "Kalender", Icons.Filled.CalendarMonth, Icons.Outlined.CalendarMonth, "nav_calendar")
    data object Stats : AppDestination("statistik", "Statistik", Icons.Filled.BarChart, Icons.Outlined.BarChart, "nav_stats")
    data object Trophies : AppDestination("troferum", "Troférum", Icons.Filled.EmojiEvents, Icons.Outlined.EmojiEvents, "nav_trophies")
    data object Profile : AppDestination("profil", "Profil", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
}

private val bottomDestinations = listOf(
    AppDestination.Start,
    AppDestination.Calendar,
    AppDestination.Stats,
    AppDestination.Trophies,
    AppDestination.Profile
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(ObsidianBlack.toArgb()),
            navigationBarStyle = SystemBarStyle.dark(CarbonSurface.toArgb())
        )
        setContent {
            val careerViewModel: CareerViewModel = viewModel()
            val timerViewModel: TimerViewModel = viewModel()
            val uiState by careerViewModel.uiState.collectAsStateWithLifecycle()
            val accentTheme = AppAccentTheme.fromId(uiState.profile?.appThemeId ?: "neon_green")

            FootballCareerTheme(accentTheme = accentTheme) {
                FootballCareerRoot(
                    careerViewModel = careerViewModel,
                    timerViewModel = timerViewModel
                )
            }
        }
    }
}

@Composable
private fun FootballCareerRoot(
    careerViewModel: CareerViewModel,
    timerViewModel: TimerViewModel
) {
    val context = LocalContext.current
    val uiState by careerViewModel.uiState.collectAsStateWithLifecycle()
    val timerState by timerViewModel.state.collectAsStateWithLifecycle()
    val unlockedAchievement by careerViewModel.recentUnlockedAchievement.collectAsStateWithLifecycle()
    val packReward by careerViewModel.lastPackReward.collectAsStateWithLifecycle()
    val seasonSummary by careerViewModel.lastSeasonSummary.collectAsStateWithLifecycle()
    val feedbackMessage by careerViewModel.feedbackMessage.collectAsStateWithLifecycle()

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val snackbarHostState = remember { SnackbarHostState() }

    var showLogMatchDialog by remember { mutableStateOf(false) }
    var showLogTrainingDialog by remember { mutableStateOf(false) }
    var trainingInitialMinutes by remember { mutableIntStateOf(60) }
    var showPackDialog by remember { mutableStateOf(false) }
    var showNotificationDialog by remember { mutableStateOf(false) }
    var selectedStatsSubTab by remember { mutableStateOf(StatsSubTab.MATCHER) }
    var hasNotificationPermission by remember {
        mutableStateOf(NotificationHelper.hasNotificationPermission(context))
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted || NotificationHelper.hasNotificationPermission(context)
    }

    // Be om notisbehörighet vid första start på Android 13+
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(feedbackMessage) {
        val msg = feedbackMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        careerViewModel.clearFeedback()
    }

    LaunchedEffect(unlockedAchievement) {
        if (unlockedAchievement != null) {
            delay(4500L)
            careerViewModel.dismissAchievementBanner()
        }
    }

    val primary = MaterialTheme.colorScheme.primary

    Box(modifier = Modifier.fillMaxSize().background(ObsidianBlack)) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = ObsidianBlack,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    containerColor = CarbonSurface,
                    contentColor = TextPrimary,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    bottomDestinations.forEach { dest ->
                        val selected = currentRoute == dest.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(AppDestination.Start.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            modifier = Modifier.testTag(dest.testTag),
                            icon = {
                                Icon(
                                    imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                    contentDescription = dest.label
                                )
                            },
                            label = {
                                Text(
                                    text = dest.label,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = ObsidianBlack,
                                selectedTextColor = primary,
                                indicatorColor = primary,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            if (uiState.isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = primary)
                }
            } else {
                NavHost(
                    navController = navController,
                    startDestination = AppDestination.Start.route,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .statusBarsPadding()
                ) {
                    composable(AppDestination.Start.route) {
                        HomeScreen(
                            uiState = uiState,
                            onOpenLogMatch = { showLogMatchDialog = true },
                            onOpenLogTraining = {
                                trainingInitialMinutes = 60
                                showLogTrainingDialog = true
                            },
                            onOpenPackDialog = { showPackDialog = true },
                            onOpenNotifications = { showNotificationDialog = true },
                            onNavigateToCalendar = {
                                navController.navigate(AppDestination.Calendar.route) {
                                    popUpTo(AppDestination.Start.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onNavigateToTimer = {
                                selectedStatsSubTab = StatsSubTab.TIMER
                                navController.navigate(AppDestination.Stats.route) {
                                    popUpTo(AppDestination.Start.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onNavigateToTrophies = {
                                navController.navigate(AppDestination.Trophies.route) {
                                    popUpTo(AppDestination.Start.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onNavigateToProfile = {
                                navController.navigate(AppDestination.Profile.route) {
                                    popUpTo(AppDestination.Start.route) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            onCompleteChallenge = { careerViewModel.completeChallenge(it) },
                            onGenerateRandomChallenge = { careerViewModel.generateRandomChallenge() }
                        )
                    }

                    composable(AppDestination.Calendar.route) {
                        CalendarScreen(
                            uiState = uiState,
                            onAddActivity = { careerViewModel.addActivity(it) },
                            onCompleteActivity = { careerViewModel.completeActivity(it) },
                            onDeleteActivity = { careerViewModel.deleteActivity(it) },
                            onOpenNotificationSettings = { showNotificationDialog = true }
                        )
                    }

                    composable(AppDestination.Stats.route) {
                        CareerStatsScreen(
                            uiState = uiState,
                            timerState = timerState,
                            timerViewModel = timerViewModel,
                            selectedSubTab = selectedStatsSubTab,
                            onSelectSubTab = { selectedStatsSubTab = it },
                            onOpenLogMatch = { showLogMatchDialog = true },
                            onOpenLogTraining = { mins ->
                                trainingInitialMinutes = mins
                                showLogTrainingDialog = true
                            },
                            onDeleteMatch = { careerViewModel.deleteMatch(it) },
                            onDeleteTraining = { careerViewModel.deleteTraining(it) }
                        )
                    }

                    composable(AppDestination.Trophies.route) {
                        TrophyRoomScreen(
                            uiState = uiState,
                            onOpenPackDialog = { showPackDialog = true },
                            onFinishSeason = { careerViewModel.finishSeason() }
                        )
                    }

                    composable(AppDestination.Profile.route) {
                        ProfileScreen(
                            uiState = uiState,
                            onSaveProfile = { careerViewModel.updateProfile(it) },
                            onSelectAppTheme = { careerViewModel.updateAppTheme(it) },
                            onOpenNotificationSettings = { showNotificationDialog = true }
                        )
                    }
                }
            }
        }

        // Animerad notis-banner i appen när en prestation låses upp
        AnimatedVisibility(
            visible = unlockedAchievement != null,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            unlockedAchievement?.let { ach ->
                val rarity = AchievementRarity.fromName(ach.rarity)
                val rColor = rarityColor(rarity)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(SlateCard)
                        .border(1.5.dp, rColor, RoundedCornerShape(18.dp))
                        .clickable {
                            careerViewModel.dismissAchievementBanner()
                            navController.navigate(AppDestination.Trophies.route)
                        }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.EmojiEvents, contentDescription = null, tint = rColor, modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("PRESTATION UPPLÅST!", style = MaterialTheme.typography.labelSmall, color = rColor)
                            Text(
                                text = ach.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                        }
                    }
                    Text("+${ach.xpReward} XP", style = MaterialTheme.typography.labelLarge, color = primary)
                }
            }
        }
    }

    if (showLogMatchDialog) {
        LogMatchDialog(
            defaultPosition = uiState.profile?.position ?: "CM",
            onSave = { opp, dateMillis, gf, ga, pos, mins, g, a, motm, rating, away, decisive, notes ->
                careerViewModel.logMatch(opp, dateMillis, gf, ga, pos, mins, g, a, motm, rating, away, decisive, notes)
                showLogMatchDialog = false
            },
            onDismiss = { showLogMatchDialog = false }
        )
    }

    if (showLogTrainingDialog) {
        LogTrainingDialog(
            initialDurationMinutes = trainingInitialMinutes,
            onSave = { type, skill, mins, intensity, rating, notes, dateMillis ->
                careerViewModel.logTraining(type, skill, mins, intensity, rating, notes, dateMillis)
                showLogTrainingDialog = false
            },
            onDismiss = { showLogTrainingDialog = false }
        )
    }

    if (showPackDialog || packReward != null) {
        PackOpeningDialog(
            unopenedCount = uiState.unopenedPacks,
            revealedReward = packReward,
            onOpenPack = { careerViewModel.openRewardPack() },
            onDismiss = {
                careerViewModel.dismissPackReward()
                showPackDialog = false
            }
        )
    }

    seasonSummary?.let { summary ->
        SeasonSummaryDialog(
            summary = summary,
            onDismiss = { careerViewModel.dismissSeasonSummary() }
        )
    }

    if (showNotificationDialog) {
        NotificationSettingsDialog(
            prefs = uiState.notificationPrefs,
            hasPermission = hasNotificationPermission,
            onRequestPermission = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            },
            onUpdatePrefs = { careerViewModel.updateNotificationPrefs(it) },
            onPreviewSound = { careerViewModel.previewSound(it) },
            onSendTestNotification = { isMatch -> careerViewModel.sendTestNotification(isMatch) },
            onDismiss = { showNotificationDialog = false }
        )
    }
}
