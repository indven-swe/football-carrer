package com.example

import com.example.data.local.MatchRecordEntity
import com.example.data.local.PlayerProfileEntity
import com.example.data.local.SeasonSummaryEntity
import com.example.data.local.TrainingRecordEntity
import com.example.domain.AchievementDefinitions
import com.example.domain.CareerEngine
import com.example.domain.TrainingIntensity
import com.example.domain.TrainingType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Calendar

class CareerEngineTest {

    private fun sampleProfile() = PlayerProfileEntity(
        id = 1,
        name = "Test Spelare",
        photoUri = null,
        position = "ANF",
        preferredFoot = "HÖGER",
        club = "Nordic FC",
        jerseyNumber = 9,
        age = 21,
        nationality = "Sverige",
        ovrRating = 65,
        level = 1,
        totalXp = 0,
        pace = 70,
        shooting = 68,
        passing = 64,
        dribbling = 67,
        defending = 50,
        physical = 65,
        cardDesign = "FUTURISTISK",
        cardBackground = "KOLFIBER",
        cardBorder = "NEON_GLÖD",
        cardColorTheme = "NEONGRÖN",
        cardRarity = "BRONS"
    )

    @Test
    fun allTwentyAchievementsAreDefinedInSwedish() {
        val list = AchievementDefinitions.createInitialAchievements()
        assertEquals(20, list.size)
        assertEquals("Första touchen", list.first().title)
        assertEquals("Fotbollstokig", list.last().title)
    }

    @Test
    fun xpAndLevelProgressionScalesFromOneToHundred() {
        val lvl1 = CareerEngine.calculateLevelProgress(0)
        assertEquals(1, lvl1.level)
        val lvl2 = CareerEngine.calculateLevelProgress(100)
        assertEquals(2, lvl2.level)
        val lvl100 = CareerEngine.calculateLevelProgress(CareerEngine.totalXpForLevel(100) + 500)
        assertEquals(100, lvl100.level)
    }

    @Test
    fun trainingAndMatchEvolutionUpdatesAttributesAndUnlocksAchievements() {
        var profile = sampleProfile()
        profile = CareerEngine.applyTrainingGrowth(profile, TrainingType.SKOTT, TrainingIntensity.HÖG, 120)
        assertTrue(profile.shooting > 68)
        assertEquals(120, profile.totalXp)

        val morningCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 6)
            set(Calendar.MINUTE, 45)
        }
        val trainings = listOf(
            TrainingRecordEntity(
                type = TrainingType.SKOTT.name,
                skillFocused = "Skott & avslut",
                durationMinutes = 60,
                intensity = TrainingIntensity.HÖG.name,
                performanceRating = 8.5f,
                notes = "",
                dateEpochMillis = morningCal.timeInMillis,
                seasonNumber = 1,
                xpEarned = 120
            )
        )
        val matches = listOf(
            MatchRecordEntity(
                opponent = "AIK U19",
                dateEpochMillis = System.currentTimeMillis(),
                goalsFor = 3,
                goalsAgainst = 1,
                position = "ANF",
                minutesPlayed = 90,
                goals = 3,
                assists = 1,
                isManOfTheMatch = true,
                performanceRating = 9.4f,
                isAway = true,
                isDecisiveGoal = true,
                notes = "",
                seasonNumber = 1,
                xpEarned = 390
            )
        )
        profile = profile.copy(totalXp = 510, level = CareerEngine.calculateLevelProgress(510).level)

        val eval = CareerEngine.evaluateAchievements(
            currentList = AchievementDefinitions.createInitialAchievements(),
            profile = profile,
            matches = matches,
            trainings = trainings,
            seasons = emptyList<SeasonSummaryEntity>(),
            hadComebackGap = false
        )

        val unlockedKeys = eval.newlyUnlocked.map { it.key }.toSet()
        assertTrue(unlockedKeys.contains("first_touch"))
        assertTrue(unlockedKeys.contains("hattrick_hero"))
        assertTrue(unlockedKeys.contains("club_100"))
        assertTrue(unlockedKeys.contains("unstoppable"))
        assertTrue(unlockedKeys.contains("morning_star"))
        assertTrue(unlockedKeys.contains("match_winner"))
    }
}
